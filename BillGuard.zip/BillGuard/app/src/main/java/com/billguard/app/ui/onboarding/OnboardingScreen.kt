package com.billguard.app.ui.onboarding

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

private data class OnboardPage(val title: String, val body: String)

private val pages = listOf(
    OnboardPage("Track Every Recurring Payment", "See every subscription and bill in one dashboard instead of scattered across apps and bank statements."),
    OnboardPage("Get Alerts Before You're Charged", "BillGuard reminds you days before a renewal or due date, so nothing catches you off guard."),
    OnboardPage("Let ULTRON Watch Your Subscriptions", "ULTRON keeps an eye on autopay renewals and free trials, and warns you before money leaves your account."),
    OnboardPage("Understand Your Spending", "Clear monthly and yearly totals, broken down by category, based only on what you've actually added.")
)

private val currencies = listOf("INR" to "\u20B9", "USD" to "$", "EUR" to "\u20AC", "GBP" to "\u00A3")

@Composable
fun OnboardingScreen(onFinished: (currencySymbol: String, currencyCode: String) -> Unit) {
    var pageIndex by remember { mutableStateOf(0) }
    var showPermissions by remember { mutableStateOf(false) }
    var selectedCurrency by remember { mutableStateOf(currencies.first()) }

    val notificationLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { /* handled gracefully regardless of the answer */ }

    if (!showPermissions) {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Spacer(Modifier.weight(1f))
            Text(pages[pageIndex].title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Text(pages[pageIndex].body, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.weight(1f))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                pages.indices.forEach { i ->
                    Box(
                        Modifier
                            .padding(4.dp)
                            .size(if (i == pageIndex) 10.dp else 8.dp)
                            .background(
                                if (i == pageIndex) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                                shape = androidx.compose.foundation.shape.CircleShape
                            )
                    )
                }
            }
            Spacer(Modifier.height(20.dp))
            Button(
                onClick = { if (pageIndex < pages.lastIndex) pageIndex++ else showPermissions = true },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) { Text(if (pageIndex < pages.lastIndex) "Next" else "Get Started") }
        }
    } else {
        Column(Modifier.fillMaxSize().padding(24.dp)) {
            Text("Set your currency", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
            Row {
                currencies.forEach { (code, symbol) ->
                    FilterChip(
                        selected = selectedCurrency.first == code,
                        onClick = { selectedCurrency = code to symbol },
                        label = { Text("$symbol $code") },
                        modifier = Modifier.padding(end = 8.dp)
                    )
                }
            }

            Spacer(Modifier.height(28.dp))
            Text("Notifications", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "BillGuard uses this to warn you before a renewal or due date.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                }
            }) { Text("Allow Notifications") }

            Spacer(Modifier.height(20.dp))
            Text("Alarms & Reminders", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(
                "Needed only if you schedule an exact-time alarm for a specific bill.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.weight(1f))
            Button(
                onClick = { onFinished(selectedCurrency.second, selectedCurrency.first) },
                modifier = Modifier.fillMaxWidth().height(50.dp)
            ) { Text("Continue to BillGuard") }
        }
    }
}
