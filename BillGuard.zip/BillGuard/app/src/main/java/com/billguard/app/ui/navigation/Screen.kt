package com.billguard.app.ui.navigation

sealed class Screen(val route: String) {
    object Splash : Screen("splash")
    object Login : Screen("login")
    object SignUp : Screen("signup")
    object Onboarding : Screen("onboarding")

    object Main : Screen("main") // hosts the bottom-nav scaffold

    object Dashboard : Screen("dashboard")
    object Subscriptions : Screen("subscriptions")
    object Bills : Screen("bills")
    object Calendar : Screen("calendar")
    object Ultron : Screen("ultron")

    object AddSubscription : Screen("add_subscription")
    object EditSubscription : Screen("edit_subscription/{id}") {
        fun path(id: Long) = "edit_subscription/$id"
    }
    object SubscriptionDetail : Screen("subscription_detail/{id}") {
        fun path(id: Long) = "subscription_detail/$id"
    }

    object AddBill : Screen("add_bill")
    object EditBill : Screen("edit_bill/{id}") {
        fun path(id: Long) = "edit_bill/$id"
    }

    object Analytics : Screen("analytics")
    object Notifications : Screen("notifications")
    object Settings : Screen("settings")
}
