package com.billguard.app.data.repository

import com.billguard.app.data.local.dao.NotificationDao
import com.billguard.app.data.local.dao.PaymentHistoryDao
import com.billguard.app.data.local.dao.PaymentMethodDao
import com.billguard.app.data.local.dao.ReminderDao
import com.billguard.app.data.local.entity.NotificationEntity
import com.billguard.app.data.local.entity.PaymentHistory
import com.billguard.app.data.local.entity.PaymentMethod
import com.billguard.app.data.local.entity.Reminder
import kotlinx.coroutines.flow.Flow

class PaymentMethodRepository(private val dao: PaymentMethodDao) {
    fun observeAll(userId: Long): Flow<List<PaymentMethod>> = dao.observeAll(userId)
    suspend fun getById(id: Long): PaymentMethod? = dao.getById(id)
    suspend fun add(method: PaymentMethod): Long = dao.insert(method)
    suspend fun update(method: PaymentMethod) = dao.update(method)
    suspend fun delete(method: PaymentMethod) = dao.delete(method)
}

class PaymentHistoryRepository(private val dao: PaymentHistoryDao) {
    fun observeAll(userId: Long): Flow<List<PaymentHistory>> = dao.observeAll(userId)
    fun observeForSubscription(userId: Long, subscriptionId: Long): Flow<List<PaymentHistory>> =
        dao.observeForSubscription(userId, subscriptionId)
    fun observeForBill(userId: Long, billId: Long): Flow<List<PaymentHistory>> =
        dao.observeForBill(userId, billId)
    suspend fun add(entry: PaymentHistory): Long = dao.insert(entry)
    suspend fun update(entry: PaymentHistory) = dao.update(entry)
}

class ReminderRepository(private val dao: ReminderDao) {
    fun observeUpcoming(userId: Long): Flow<List<Reminder>> = dao.observeUpcoming(userId)
    suspend fun getForSubscription(subscriptionId: Long): List<Reminder> = dao.getForSubscription(subscriptionId)
    suspend fun getForBill(billId: Long): List<Reminder> = dao.getForBill(billId)
    suspend fun add(reminder: Reminder): Long = dao.insert(reminder)
    suspend fun update(reminder: Reminder) = dao.update(reminder)
    suspend fun delete(reminder: Reminder) = dao.delete(reminder)
    suspend fun deleteForSubscription(subscriptionId: Long) = dao.deleteForSubscription(subscriptionId)
    suspend fun deleteForBill(billId: Long) = dao.deleteForBill(billId)
    suspend fun getAllEnabled(): List<Reminder> = dao.getAllEnabled()
}

class NotificationRepository(private val dao: NotificationDao) {
    fun observeAll(userId: Long): Flow<List<NotificationEntity>> = dao.observeAll(userId)
    fun observeUnreadCount(userId: Long): Flow<Int> = dao.observeUnreadCount(userId)
    suspend fun add(notification: NotificationEntity): Long = dao.insert(notification)
    suspend fun markRead(id: Long) = dao.markRead(id)
    suspend fun markAllRead(userId: Long) = dao.markAllRead(userId)
    suspend fun delete(notification: NotificationEntity) = dao.delete(notification)
}
