package com.billguard.app.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.billguard.app.data.local.entity.Reminder

/**
 * Wraps AlarmManager so the rest of the app never touches the OS APIs directly. Exact alarms
 * degrade gracefully to an inexact alarm if the user hasn't granted SCHEDULE_EXACT_ALARM (Android
 * 12+) instead of crashing — see section 15 / 33.
 */
object ReminderScheduler {

    fun canScheduleExactAlarms(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        return alarmManager.canScheduleExactAlarms()
    }

    fun schedule(context: Context, reminder: Reminder) {
        if (!reminder.enabled || reminder.reminderDateTime < System.currentTimeMillis()) return
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

        val intent = Intent(context, ReminderBroadcastReceiver::class.java).apply {
            putExtra(ReminderBroadcastReceiver.EXTRA_REMINDER_ID, reminder.reminderId)
            putExtra(ReminderBroadcastReceiver.EXTRA_ITEM_NAME, reminder.itemName)
            putExtra(ReminderBroadcastReceiver.EXTRA_IS_SUBSCRIPTION, reminder.subscriptionId != null)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context, reminder.alarmRequestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        runCatching {
            if (canScheduleExactAlarms(context)) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP, reminder.reminderDateTime, pendingIntent
                )
            } else {
                // Falls back to an inexact-but-still-delivered alarm rather than silently failing.
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP, reminder.reminderDateTime, pendingIntent
                )
            }
        }
    }

    fun cancel(context: Context, reminder: Reminder) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(context, ReminderBroadcastReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, reminder.alarmRequestCode, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
    }
}
