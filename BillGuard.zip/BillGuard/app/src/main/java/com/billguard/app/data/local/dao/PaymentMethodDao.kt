package com.billguard.app.data.local.dao

import androidx.room.*
import com.billguard.app.data.local.entity.PaymentMethod
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentMethodDao {
    @Insert
    suspend fun insert(paymentMethod: PaymentMethod): Long

    @Update
    suspend fun update(paymentMethod: PaymentMethod)

    @Delete
    suspend fun delete(paymentMethod: PaymentMethod)

    @Query("SELECT * FROM payment_methods WHERE userId = :userId")
    fun observeAll(userId: Long): Flow<List<PaymentMethod>>

    @Query("SELECT * FROM payment_methods WHERE paymentMethodId = :id LIMIT 1")
    suspend fun getById(id: Long): PaymentMethod?
}
