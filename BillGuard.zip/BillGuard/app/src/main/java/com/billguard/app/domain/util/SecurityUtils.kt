package com.billguard.app.domain.util

import java.security.MessageDigest
import java.security.SecureRandom

/**
 * Local/demo authentication: passwords are never stored in plaintext. Each user gets a random
 * salt; the stored hash is SHA-256(password + salt), repeated for extra cost. The architecture
 * (see UserRepository / User.authProvider) is deliberately separated so Firebase Authentication
 * can be dropped in later without touching the rest of the app — see the README for exactly
 * where that plug-in point is.
 */
object SecurityUtils {
    private const val ITERATIONS = 10_000

    fun generateSalt(): String {
        val bytes = ByteArray(16)
        SecureRandom().nextBytes(bytes)
        return bytes.joinToString("") { "%02x".format(it) }
    }

    fun hashPassword(password: String, salt: String): String {
        var result = (password + salt).toByteArray(Charsets.UTF_8)
        val digest = MessageDigest.getInstance("SHA-256")
        repeat(ITERATIONS) {
            result = digest.digest(result)
        }
        return result.joinToString("") { "%02x".format(it) }
    }
}
