package com.billguard.app.ultron

import com.billguard.app.data.local.entity.Bill
import com.billguard.app.data.local.entity.Subscription
import com.billguard.app.data.local.entity.User
import com.billguard.app.domain.util.DateCalculations
import com.billguard.app.domain.util.SpendingCalculator

/**
 * ULTRON deliberately has no call to any AI API: everything it says is computed from the
 * subscriptions/bills already in Room. This is what satisfies "ULTRON must only use actual
 * application data. Never invent transactions" — and it means the assistant keeps working
 * completely offline. The README explains exactly where a real LLM call could be substituted
 * in later if the user wants free-form conversation instead of these rule-based answers.
 */
object UltronEngine {

    fun respond(
        query: String,
        user: User?,
        subscriptions: List<Subscription>,
        bills: List<Bill>
    ): String {
        val q = query.trim().lowercase()
        val symbol = user?.currencySymbol ?: "\u20B9"
        val active = subscriptions.filter { it.status == "ACTIVE" || it.status == "TRIAL" }
        val activeBills = bills.filter { it.status == "ACTIVE" }

        return when {
            q.contains("most expensive") -> mostExpensive(active, activeBills, symbol)
            q.contains("this week") || q.contains("coming") && q.contains("week") -> upcoming(active, activeBills, 7, symbol)
            q.contains("this month") -> upcoming(active, activeBills, 30, symbol)
            q.contains("next payment") || q.contains("next renewal") -> nextPayment(active, activeBills, symbol)
            q.contains("every month") || q.contains("per month") || (q.contains("spend") && q.contains("month")) -> monthlySpend(active, activeBills, symbol)
            q.contains("this year") || q.contains("yearly") || q.contains("per year") -> yearlySpend(active, activeBills, symbol)
            q.contains("trial") -> trials(active, symbol)
            q.contains("autopay") -> autopayList(active, activeBills)
            q.contains("overdue") -> overdue(activeBills, symbol)
            q.contains("reduce") || q.contains("save money") || q.contains("cut") -> reduceSpending(active, activeBills, symbol)
            q.contains("no longer need") || q.contains("don't need") || q.contains("cancel") -> howToCancel()
            q.contains("didn't arrive") || q.contains("reminder") && q.contains("not") -> troubleshootReminder()
            q.contains("why") && q.contains("reminder") -> whyReminder()
            else -> fallback()
        }
    }

    private fun fmt(symbol: String, amount: Double) = "$symbol${"%.2f".format(amount)}"

    private fun nextPayment(subs: List<Subscription>, bills: List<Bill>, symbol: String): String {
        val items = SpendingCalculator.upcomingWithinDays(subs, bills, 3650)
        val next = items.minByOrNull { it.daysRemaining } ?: return "You have no upcoming subscriptions or bills on file yet."
        val when_ = when {
            next.daysRemaining == 0L -> "today"
            next.daysRemaining == 1L -> "tomorrow"
            else -> "in ${next.daysRemaining} days"
        }
        return "Your next payment is ${next.name} — ${fmt(next.currencySymbol.ifBlank { symbol }, next.amount)}, $when_."
    }

    private fun upcoming(subs: List<Subscription>, bills: List<Bill>, days: Int, symbol: String): String {
        val items = SpendingCalculator.upcomingWithinDays(subs, bills, days.toLong())
        if (items.isEmpty()) return "Nothing is due in the next $days days — you're clear for now."
        val total = items.sumOf { it.amount }
        val lines = items.joinToString("\n") { "• ${it.name} — ${fmt(symbol, it.amount)} in ${it.daysRemaining}d" }
        return "You have ${items.size} payment${if (items.size == 1) "" else "s"} in the next $days days totaling ${fmt(symbol, total)}:\n$lines"
    }

    private fun monthlySpend(subs: List<Subscription>, bills: List<Bill>, symbol: String): String {
        val summary = SpendingCalculator.summarize(subs, bills)
        return "Based on what's stored, you spend about ${fmt(symbol, summary.monthlyTotal)} per month across ${subs.size} subscription${if (subs.size == 1) "" else "s"} and ${bills.size} bill${if (bills.size == 1) "" else "s"}."
    }

    private fun yearlySpend(subs: List<Subscription>, bills: List<Bill>, symbol: String): String {
        val summary = SpendingCalculator.summarize(subs, bills)
        return "At the current rate, that projects to about ${fmt(symbol, summary.yearlyTotal)} this year."
    }

    private fun mostExpensive(subs: List<Subscription>, bills: List<Bill>, symbol: String): String {
        val summary = SpendingCalculator.summarize(subs, bills)
        return if (summary.mostExpensiveName != null)
            "Your most expensive recurring item is ${summary.mostExpensiveName} at about ${fmt(symbol, summary.mostExpensiveMonthly)}/month."
        else "You don't have any active subscriptions or bills yet."
    }

    private fun trials(subs: List<Subscription>, symbol: String): String {
        val trials = subs.filter { it.isTrial && it.trialEnd != null }
        if (trials.isEmpty()) return "You don't have any free trials running right now."
        val lines = trials.joinToString("\n") {
            val remaining = DateCalculations.daysRemaining(it.trialEnd!!)
            "• ${it.name} — ends in $remaining day${if (remaining == 1L) "" else "s"}" +
                (it.postTrialAmount?.let { amt -> ", then ${fmt(symbol, amt)}" } ?: "")
        }
        return "Free trials ending soon:\n$lines"
    }

    private fun autopayList(subs: List<Subscription>, bills: List<Bill>): String {
        val subNames = subs.filter { it.autopay }.map { it.name }
        val billNames = bills.filter { it.autopay }.map { it.name }
        val all = subNames + billNames
        return if (all.isEmpty()) "Nothing currently has autopay turned on."
        else "Autopay is ON for: ${all.joinToString(", ")}. You can flip any of these off from its detail screen."
    }

    private fun overdue(bills: List<Bill>, symbol: String): String {
        val overdue = bills.filter { DateCalculations.daysRemaining(it.dueDate) < 0 }
        if (overdue.isEmpty()) return "Nothing looks overdue right now. If a specific bill still seems wrong, open it and tap \"Mark as Paid\" or edit its due date."
        val lines = overdue.joinToString("\n") { "• ${it.name} — ${fmt(it.currencySymbol.ifBlank { symbol }, it.amount)}, was due ${DateCalculations.formatDate(it.dueDate)}" }
        return "These look overdue based on their due dates:\n$lines\nIf you've already paid one, mark it as paid so it stops being flagged."
    }

    private fun reduceSpending(subs: List<Subscription>, bills: List<Bill>, symbol: String): String {
        val summary = SpendingCalculator.summarize(subs, bills)
        val sortedByCategory = summary.categoryBreakdown.entries.sortedByDescending { it.value }
        val top = sortedByCategory.firstOrNull()
        return buildString {
            append("A few things worth reviewing: ")
            if (top != null) append("your biggest category is ${top.key} at about ${fmt(symbol, top.value)}/month. ")
            append("Check subscriptions you haven't opened in a while, anything still in a free trial you don't plan to keep, and duplicate services in the same category — those are the usual places money leaks out.")
        }
    }

    private fun howToCancel(): String =
        "Open the subscription's detail page and tap Cancel or Pause. If autopay is on with your bank or card directly (not through BillGuard), you may also need to turn it off from the provider's own app or website — BillGuard can't cancel a bank-side autopay for you unless that provider is directly integrated."

    private fun troubleshootReminder(): String =
        "A few things to check: notifications are enabled for BillGuard in your phone's Settings, the reminder wasn't accidentally disabled on that item's detail page, and battery optimization isn't restricting BillGuard in the background. If all of that looks right and it still didn't arrive, it may be a one-off — the next scheduled reminder should still fire normally."

    private fun whyReminder(): String =
        "You got that reminder because one of your reminder offsets (like 7, 3, or 1 day before) matched how close the renewal or due date is. You can change which offsets are active from the item's detail screen."

    private fun fallback(): String =
        "I can help with things like your next payment, monthly or yearly spending, which subscriptions have autopay, free trials ending soon, or overdue bills — try asking one of those, or open a specific subscription and tap \"Ask ULTRON\" for details on just that item."
}
