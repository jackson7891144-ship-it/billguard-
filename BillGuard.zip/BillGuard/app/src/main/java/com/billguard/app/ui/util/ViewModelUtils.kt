package com.billguard.app.ui.util

import androidx.compose.runtime.Composable
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory

/**
 * All of our ViewModels take constructor args (AppContainer, userId, ...) instead of using a DI
 * framework, so this small wrapper is what lets every screen write
 * `val vm: FooViewModel = viewModel { FooViewModel(container, userId) }`
 * instead of hand-rolling a ViewModelProvider.Factory each time.
 */
@Composable
inline fun <reified VM : ViewModel> viewModel(crossinline creator: () -> VM): VM {
    return viewModel(factory = viewModelFactory { initializer { creator() } })
}
