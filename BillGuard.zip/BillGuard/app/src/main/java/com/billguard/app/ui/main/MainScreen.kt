package com.billguard.app.ui.main

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.billguard.app.AppContainer
import com.billguard.app.ui.analytics.AnalyticsScreen
import com.billguard.app.ui.analytics.AnalyticsViewModel
import com.billguard.app.ui.bills.BillsListScreen
import com.billguard.app.ui.bills.BillsViewModel
import com.billguard.app.ui.calendar.CalendarScreen
import com.billguard.app.ui.calendar.CalendarViewModel
import com.billguard.app.ui.dashboard.DashboardScreen
import com.billguard.app.ui.dashboard.DashboardViewModel
import com.billguard.app.ui.navigation.Screen
import com.billguard.app.ui.notifications.NotificationCenterScreen
import com.billguard.app.ui.notifications.NotificationsViewModel
import com.billguard.app.ui.settings.SettingsScreen
import com.billguard.app.ui.settings.SettingsViewModel
import com.billguard.app.ui.ultron.UltronScreen
import com.billguard.app.ui.ultron.UltronViewModel
import com.billguard.app.ui.util.viewModel

private data class BottomItem(val screen: Screen, val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

private val bottomItems = listOf(
    BottomItem(Screen.Dashboard, "Home", Icons.Filled.Home),
    BottomItem(Screen.Subscriptions, "Subs", Icons.Filled.Subscriptions),
    BottomItem(Screen.Bills, "Bills", Icons.Filled.ReceiptLong),
    BottomItem(Screen.Calendar, "Calendar", Icons.Filled.CalendarMonth),
    BottomItem(Screen.Ultron, "ULTRON", Icons.Filled.SmartToy)
)

@Composable
fun MainScreen(
    container: AppContainer,
    userId: Long,
    outerNav: NavHostController,
    onThemeModeChange: (com.billguard.app.domain.AppThemeMode) -> Unit
) {
    val innerNav = rememberNavController()
    val backStackEntry by innerNav.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route
    var showAddSheet by remember { mutableStateOf(false) }

    Scaffold(
        bottomBar = {
            NavigationBar {
                bottomItems.forEach { item ->
                    NavigationBarItem(
                        selected = currentRoute == item.screen.route,
                        onClick = {
                            innerNav.navigate(item.screen.route) {
                                popUpTo(innerNav.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(item.icon, contentDescription = item.label) },
                        label = { Text(item.label) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (currentRoute == Screen.Dashboard.route || currentRoute == Screen.Subscriptions.route || currentRoute == Screen.Bills.route) {
                FloatingActionButton(onClick = { showAddSheet = true }) {
                    Icon(Icons.Filled.Add, contentDescription = "Add")
                }
            }
        },
        topBar = {
            TopAppBar(
                title = { Text(bottomItems.firstOrNull { it.screen.route == currentRoute }?.label ?: "BillGuard") },
                actions = {
                    IconButton(onClick = { outerNav.navigate(Screen.Notifications.route) }) {
                        Icon(Icons.Filled.Notifications, contentDescription = "Notifications")
                    }
                    IconButton(onClick = { outerNav.navigate(Screen.Settings.route) }) {
                        Icon(Icons.Filled.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        NavHost(
            navController = innerNav,
            startDestination = Screen.Dashboard.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Dashboard.route) {
                val vm: DashboardViewModel = viewModel { DashboardViewModel(container, userId) }
                DashboardScreen(
                    viewModel = vm,
                    onOpenSubscription = { outerNav.navigate(Screen.SubscriptionDetail.path(it)) },
                    onOpenBill = { outerNav.navigate(Screen.EditBill.path(it)) },
                    onOpenAnalytics = { outerNav.navigate(Screen.Analytics.route) }
                )
            }
            composable(Screen.Subscriptions.route) {
                val vm: com.billguard.app.ui.subscriptions.SubscriptionsViewModel = viewModel { com.billguard.app.ui.subscriptions.SubscriptionsViewModel(container, userId) }
                SubscriptionsListWrapper(vm, outerNav)
            }
            composable(Screen.Bills.route) {
                val vm: BillsViewModel = viewModel { BillsViewModel(container, userId) }
                BillsListScreen(
                    viewModel = vm,
                    onAdd = { outerNav.navigate(Screen.AddBill.route) },
                    onOpen = { outerNav.navigate(Screen.EditBill.path(it)) }
                )
            }
            composable(Screen.Calendar.route) {
                val vm: CalendarViewModel = viewModel { CalendarViewModel(container, userId) }
                CalendarScreen(
                    viewModel = vm,
                    onOpenSubscription = { outerNav.navigate(Screen.SubscriptionDetail.path(it)) },
                    onOpenBill = { outerNav.navigate(Screen.EditBill.path(it)) }
                )
            }
            composable(Screen.Ultron.route) {
                val vm: UltronViewModel = viewModel { UltronViewModel(container, userId) }
                UltronScreen(viewModel = vm)
            }
        }
    }

    if (showAddSheet) {
        ModalBottomSheet(onDismissRequest = { showAddSheet = false }) {
            Column(Modifier.padding(16.dp).padding(bottom = 24.dp)) {
                ListItem(
                    headlineContent = { Text("Add Subscription") },
                    leadingContent = { Icon(Icons.Filled.Subscriptions, contentDescription = null) },
                    modifier = Modifier.clickable { showAddSheet = false; outerNav.navigate(Screen.AddSubscription.route) }
                )
                ListItem(
                    headlineContent = { Text("Add Bill") },
                    leadingContent = { Icon(Icons.Filled.ReceiptLong, contentDescription = null) },
                    modifier = Modifier.clickable { showAddSheet = false; outerNav.navigate(Screen.AddBill.route) }
                )
            }
        }
    }
}

@Composable
private fun SubscriptionsListWrapper(vm: com.billguard.app.ui.subscriptions.SubscriptionsViewModel, outerNav: NavHostController) {
    com.billguard.app.ui.subscriptions.SubscriptionsListScreen(
        viewModel = vm,
        onAdd = { outerNav.navigate(Screen.AddSubscription.route) },
        onOpen = { outerNav.navigate(Screen.SubscriptionDetail.path(it)) }
    )
}

private fun Modifier.clickable(onClick: () -> Unit): Modifier = this.then(androidx.compose.foundation.clickable(onClick = onClick))
