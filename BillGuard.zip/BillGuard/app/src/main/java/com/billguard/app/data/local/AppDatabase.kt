package com.billguard.app.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.billguard.app.data.local.dao.*
import com.billguard.app.data.local.entity.*

@Database(
    entities = [
        User::class,
        Subscription::class,
        Bill::class,
        PaymentMethod::class,
        PaymentHistory::class,
        Reminder::class,
        NotificationEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun subscriptionDao(): SubscriptionDao
    abstract fun billDao(): BillDao
    abstract fun paymentMethodDao(): PaymentMethodDao
    abstract fun paymentHistoryDao(): PaymentHistoryDao
    abstract fun reminderDao(): ReminderDao
    abstract fun notificationDao(): NotificationDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "billguard_database"
                )
                    // Every schema change from here on should be a real Migration, not this
                    // fallback — kept only so early development builds never crash on you.
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
    }
}
