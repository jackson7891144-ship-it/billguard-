package com.billguard.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

// SAFETY NOTE: This entity intentionally has no field for CVV, UPI PIN, ATM PIN, or any
// banking password. BillGuard is a tracking/reminder app, never a credential store.
@Entity(
    tableName = "payment_methods",
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["userId"],
        childColumns = ["userId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("userId")]
)
data class PaymentMethod(
    @PrimaryKey(autoGenerate = true) val paymentMethodId: Long = 0,
    val userId: Long,
    val nickname: String,
    val type: String, // PaymentMethodType.name
    val issuer: String = "",
    val lastFourDigits: String? = null,
    val expiryMonth: Int? = null,
    val expiryYear: Int? = null
)
