package com.billguard.app.data.repository

import com.billguard.app.data.local.dao.BillDao
import com.billguard.app.data.local.entity.Bill
import kotlinx.coroutines.flow.Flow

class BillRepository(private val dao: BillDao) {
    fun observeAll(userId: Long): Flow<List<Bill>> = dao.observeAll(userId)
    fun observeActive(userId: Long): Flow<List<Bill>> = dao.observeActive(userId)
    fun observeById(id: Long): Flow<Bill?> = dao.observeById(id)
    fun search(userId: Long, query: String): Flow<List<Bill>> = dao.search(userId, query)

    suspend fun getActiveOnce(userId: Long): List<Bill> = dao.getActiveOnce(userId)
    suspend fun getById(id: Long): Bill? = dao.getById(id)

    suspend fun add(bill: Bill): Long = dao.insert(bill)
    suspend fun update(bill: Bill) = dao.update(bill)
    suspend fun delete(bill: Bill) = dao.delete(bill)
    suspend fun setStatus(bill: Bill, status: String) = dao.update(bill.copy(status = status))
}
