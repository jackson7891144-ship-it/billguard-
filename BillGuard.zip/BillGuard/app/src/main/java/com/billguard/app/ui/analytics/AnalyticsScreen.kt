package com.billguard.app.ui.analytics

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.Bill
import com.billguard.app.data.local.entity.Subscription
import com.billguard.app.domain.util.SpendingCalculator
import com.billguard.app.domain.util.SpendingSummary
import com.billguard.app.ui.components.SectionCard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

private val donutPalette = listOf(
    Color(0xFF1FAA59), Color(0xFF66BB6A), Color(0xFFA5D6A7), Color(0xFFF2A93B),
    Color(0xFF4FC3F7), Color(0xFF9575CD), Color(0xFFE57373), Color(0xFF90A4AE)
)

data class AnalyticsState(
    val summary: SpendingSummary = SpendingSummary(0.0, 0.0, emptyMap(), null, 0.0),
    val subscriptionCount: Int = 0,
    val billCount: Int = 0,
    val currencySymbol: String = "\u20B9"
)

class AnalyticsViewModel(private val container: AppContainer, private val userId: Long) : ViewModel() {
    private val _state = MutableStateFlow(AnalyticsState())
    val state: StateFlow<AnalyticsState> = _state

    init {
        viewModelScope.launch {
            val symbol = container.userRepository.getUser(userId)?.currencySymbol ?: "\u20B9"
            combine(
                container.subscriptionRepository.observeActive(userId),
                container.billRepository.observeActive(userId)
            ) { subs, bills -> Triple(subs, bills, SpendingCalculator.summarize(subs, bills)) }
                .collectLatest { (subs, bills, summary) ->
                    _state.value = AnalyticsState(summary, subs.size, bills.size, symbol)
                }
        }
    }
}

@Composable
fun AnalyticsScreen(viewModel: AnalyticsViewModel) {
    val state by viewModel.state.collectAsState()
    val symbol = state.currencySymbol
    val categories = state.summary.categoryBreakdown.entries.sortedByDescending { it.value }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScrollCompat()) {
        Text("Analytics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SectionCard(modifier = Modifier.weight(1f)) {
                Text("Monthly Spending", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$symbol${"%.0f".format(state.summary.monthlyTotal)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
            SectionCard(modifier = Modifier.weight(1f)) {
                Text("Yearly Projection", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text("$symbol${"%.0f".format(state.summary.yearlyTotal)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(Modifier.height(14.dp))
        SectionCard {
            Text("Category Breakdown", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(12.dp))
            if (categories.isEmpty()) {
                Text("Add a subscription or bill to see your breakdown.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    DonutChart(categories.map { it.value }, categories.mapIndexed { i, _ -> donutPalette[i % donutPalette.size] }, Modifier.size(120.dp))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        categories.forEachIndexed { i, entry ->
                            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                                Box(Modifier.size(10.dp).background(donutPalette[i % donutPalette.size], CircleShape))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "${entry.key.lowercase().replaceFirstChar { c -> c.uppercase() }} · $symbol${"%.0f".format(entry.value)}",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        SectionCard {
            state.summary.mostExpensiveName?.let {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Most Expensive", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text("$it — $symbol${"%.0f".format(state.summary.mostExpensiveMonthly)}/mo", fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(8.dp))
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Active Subscriptions", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(state.subscriptionCount.toString(), fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Recurring Bills", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(state.billCount.toString(), fontWeight = FontWeight.Medium)
            }
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun DonutChart(values: List<Double>, colors: List<Color>, modifier: Modifier = Modifier) {
    val total = values.sum().takeIf { it > 0 } ?: 1.0
    Canvas(modifier = modifier) {
        var startAngle = -90f
        val strokeWidth = size.minDimension * 0.22f
        values.forEachIndexed { i, value ->
            val sweep = (value / total * 360.0).toFloat()
            drawArc(
                color = colors[i],
                startAngle = startAngle,
                sweepAngle = sweep,
                useCenter = false,
                style = Stroke(width = strokeWidth),
                size = Size(size.width - strokeWidth, size.height - strokeWidth),
                topLeft = androidx.compose.ui.geometry.Offset(strokeWidth / 2, strokeWidth / 2)
            )
            startAngle += sweep
        }
    }
}

@Composable
private fun Modifier.verticalScrollCompat(): Modifier {
    val scrollState = androidx.compose.foundation.rememberScrollState()
    return this.then(androidx.compose.foundation.verticalScroll(scrollState))
}
