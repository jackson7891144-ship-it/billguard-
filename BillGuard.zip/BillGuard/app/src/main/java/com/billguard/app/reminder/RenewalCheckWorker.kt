package com.billguard.app.reminder

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.billguard.app.BillGuardApplication
import com.billguard.app.data.local.entity.NotificationEntity
import com.billguard.app.domain.util.DateCalculations
import com.billguard.app.domain.util.SpendingCalculator
import kotlinx.coroutines.flow.first

/**
 * Runs roughly once a day (scheduled from MainActivity/SettingsViewModel via WorkManager's
 * periodic API). For every user, checks upcoming subscriptions/bills and free trials, and posts
 * a real notification for anything hitting the 7/3/1/0-day thresholds. This is what makes
 * ULTRON's warnings actually proactive instead of only answering when asked.
 */
class RenewalCheckWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    private val WARNING_DAYS = setOf(7L, 3L, 2L, 1L, 0L)

    override suspend fun doWork(): Result {
        val app = applicationContext as BillGuardApplication
        val container = app.container

        val userId = container.sessionManager.loggedInUserId.first() ?: return Result.success()
        val notificationsOn = container.sessionManager.notificationsEnabled.first()
        if (!notificationsOn) return Result.success()

        val subscriptions = container.subscriptionRepository.getActiveOnce(userId)
        val bills = container.billRepository.getActiveOnce(userId)

        for (sub in subscriptions) {
            val remaining = DateCalculations.daysRemaining(sub.renewalDate)
            if (remaining in WARNING_DAYS) {
                val autopayNote = if (sub.autopay) " Autopay is ON, so it will renew automatically unless you cancel it." else " Autopay is OFF — you'll need to pay manually to keep it active."
                val title = if (remaining == 0L) "${sub.name} renews today" else "${sub.name} renews in $remaining day${if (remaining == 1L) "" else "s"}"
                val message = "${sub.currencySymbol}${"%.2f".format(sub.amount)} on ${DateCalculations.formatDate(sub.renewalDate)}.$autopayNote"
                postAndSave(container, userId, title, message, "AUTOPAY_WARNING", subscriptionId = sub.subscriptionId, notifId = (sub.subscriptionId * 10 + remaining).toInt())
            }
            if (sub.isTrial && sub.trialEnd != null) {
                val trialRemaining = DateCalculations.daysRemaining(sub.trialEnd)
                if (trialRemaining in WARNING_DAYS) {
                    val amountNote = sub.postTrialAmount?.let { "${sub.currencySymbol}${"%.2f".format(it)} may be charged after the trial." } ?: "A recurring charge may begin after the trial."
                    postAndSave(
                        container, userId,
                        title = "${sub.name} free trial ends in $trialRemaining day${if (trialRemaining == 1L) "" else "s"}",
                        message = amountNote,
                        type = "TRIAL_REMINDER",
                        subscriptionId = sub.subscriptionId,
                        notifId = (sub.subscriptionId * 100 + trialRemaining).toInt()
                    )
                }
            }
        }

        for (bill in bills) {
            val remaining = DateCalculations.daysRemaining(bill.dueDate)
            if (remaining in WARNING_DAYS) {
                val title = if (remaining == 0L) "${bill.name} is due today" else "${bill.name} due in $remaining day${if (remaining == 1L) "" else "s"}"
                val message = "${bill.currencySymbol}${"%.2f".format(bill.amount)} due on ${DateCalculations.formatDate(bill.dueDate)}."
                postAndSave(container, userId, title, message, "PAYMENT_REMINDER", billId = bill.billId, notifId = (bill.billId * 10 + remaining).toInt() + 500_000)
            } else if (remaining < 0) {
                postAndSave(container, userId, "${bill.name} is overdue", "This bill was due on ${DateCalculations.formatDate(bill.dueDate)}.", "BILL_OVERDUE", billId = bill.billId, notifId = (bill.billId).toInt() + 900_000)
            }
        }

        // Spending-target check (section 21)
        val user = container.userRepository.getUser(userId)
        val target = user?.monthlySpendingTarget
        if (target != null && target > 0) {
            val summary = SpendingCalculator.summarize(subscriptions, bills)
            if (summary.monthlyTotal > target) {
                postAndSave(
                    container, userId,
                    title = "Monthly spending target exceeded",
                    message = "You're at ${user.currencySymbol}${"%.2f".format(summary.monthlyTotal)} against a target of ${user.currencySymbol}${"%.2f".format(target)}.",
                    type = "SPENDING_WARNING",
                    notifId = 999_999
                )
            }
        }

        return Result.success()
    }

    private suspend fun postAndSave(
        container: com.billguard.app.AppContainer,
        userId: Long,
        title: String,
        message: String,
        type: String,
        subscriptionId: Long? = null,
        billId: Long? = null,
        notifId: Int
    ) {
        NotificationHelper.ensureChannels(applicationContext)
        NotificationHelper.showNotification(applicationContext, notifId, title, message)
        container.notificationRepository.add(
            NotificationEntity(
                userId = userId,
                title = title,
                message = message,
                type = type,
                relatedSubscriptionId = subscriptionId,
                relatedBillId = billId
            )
        )
    }
}

/** Re-reads every enabled Reminder row from Room and re-arms its AlarmManager alarm after a reboot. */
class RescheduleRemindersWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val app = applicationContext as BillGuardApplication
        val reminders = app.container.reminderRepository.getAllEnabled()
        reminders.forEach { ReminderScheduler.schedule(applicationContext, it) }
        return Result.success()
    }
}
