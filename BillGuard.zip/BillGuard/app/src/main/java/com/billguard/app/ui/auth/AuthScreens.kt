package com.billguard.app.ui.auth

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.data.repository.UserRepository
import com.billguard.app.domain.util.SessionManager
import com.billguard.app.domain.util.Validators
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class AuthUiState(
    val loading: Boolean = false,
    val errorMessage: String? = null
)

class AuthViewModel(
    private val userRepository: UserRepository,
    private val sessionManager: SessionManager
) : ViewModel() {

    private val _state = MutableStateFlow(AuthUiState())
    val state: StateFlow<AuthUiState> = _state

    fun login(email: String, password: String, rememberMe: Boolean, onSuccess: () -> Unit) {
        if (!Validators.isValidEmail(email)) { _state.value = AuthUiState(errorMessage = "Enter a valid email address."); return }
        if (password.isBlank()) { _state.value = AuthUiState(errorMessage = "Enter your password."); return }

        _state.value = AuthUiState(loading = true)
        viewModelScope.launch {
            when (val result = userRepository.login(email, password)) {
                is UserRepository.AuthResult.Success -> {
                    sessionManager.setLoggedInUser(result.user.userId, rememberMe)
                    _state.value = AuthUiState()
                    onSuccess()
                }
                is UserRepository.AuthResult.UserNotFound -> _state.value = AuthUiState(errorMessage = "No account found with that email.")
                is UserRepository.AuthResult.InvalidCredentials -> _state.value = AuthUiState(errorMessage = "Incorrect password.")
                else -> _state.value = AuthUiState(errorMessage = "Something went wrong. Please try again.")
            }
        }
    }

    fun signUp(name: String, email: String, phone: String, password: String, confirm: String, onSuccess: () -> Unit) {
        if (!Validators.isNotBlank(name)) { _state.value = AuthUiState(errorMessage = "Enter your full name."); return }
        if (!Validators.isValidEmail(email)) { _state.value = AuthUiState(errorMessage = "Enter a valid email address."); return }
        if (!Validators.isValidPhone(phone)) { _state.value = AuthUiState(errorMessage = "Enter a valid phone number."); return }
        if (!Validators.isStrongPassword(password)) { _state.value = AuthUiState(errorMessage = "Password needs 8+ characters with a letter and a number."); return }
        if (!Validators.passwordsMatch(password, confirm)) { _state.value = AuthUiState(errorMessage = "Passwords don't match."); return }

        _state.value = AuthUiState(loading = true)
        viewModelScope.launch {
            when (val result = userRepository.signUp(name, email, phone, password, currency = "INR")) {
                is UserRepository.AuthResult.Success -> {
                    sessionManager.setLoggedInUser(result.user.userId, rememberMe = true)
                    _state.value = AuthUiState()
                    onSuccess()
                }
                is UserRepository.AuthResult.EmailAlreadyExists -> _state.value = AuthUiState(errorMessage = "An account with this email already exists.")
                else -> _state.value = AuthUiState(errorMessage = "Something went wrong. Please try again.")
            }
        }
    }

    fun clearError() { _state.value = _state.value.copy(errorMessage = null) }
}

@Composable
fun LoginScreen(
    viewModel: AuthViewModel,
    onLoginSuccess: () -> Unit,
    onNavigateToSignUp: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var rememberMe by remember { mutableStateOf(true) }
    val state by viewModel.state.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Welcome back", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Log in to keep tracking your bills.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(28.dp))

        OutlinedTextField(
            value = email, onValueChange = { email = it }, label = { Text("Email") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = password, onValueChange = { password = it }, label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Spacer(Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = rememberMe, onCheckedChange = { rememberMe = it })
            Text("Remember me", style = MaterialTheme.typography.bodyMedium)
        }

        state.errorMessage?.let {
            Spacer(Modifier.height(4.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { viewModel.login(email, password, rememberMe, onLoginSuccess) },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            enabled = !state.loading
        ) { Text(if (state.loading) "Logging in..." else "Log In") }

        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = { /* Google Sign-In: wire to Firebase Auth here — see README */ },
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) { Text("Continue with Google") }

        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            Text("Don't have an account? ", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Sign Up",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clickableText(onNavigateToSignUp)
            )
        }
    }
}

@Composable
fun SignUpScreen(
    viewModel: AuthViewModel,
    onSignUpSuccess: () -> Unit,
    onNavigateToLogin: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    val state by viewModel.state.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp)
    ) {
        Spacer(Modifier.height(24.dp))
        Text("Create your account", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text("Track every subscription in one place.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(24.dp))

        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Full Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email), modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = phone, onValueChange = { phone = it }, label = { Text("Phone Number") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = confirm, onValueChange = { confirm = it }, label = { Text("Confirm Password") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password), modifier = Modifier.fillMaxWidth(), singleLine = true)

        state.errorMessage?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { viewModel.signUp(name, email, phone, password, confirm, onSignUpSuccess) },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            enabled = !state.loading
        ) { Text(if (state.loading) "Creating account..." else "Create Account") }

        Spacer(Modifier.height(10.dp))
        OutlinedButton(onClick = { }, modifier = Modifier.fillMaxWidth().height(50.dp)) { Text("Continue with Google") }

        Spacer(Modifier.height(16.dp))
        Text(
            "By continuing you agree to BillGuard's Terms & Conditions and Privacy Policy.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Spacer(Modifier.height(16.dp))
        Row(horizontalArrangement = Arrangement.Center, modifier = Modifier.fillMaxWidth()) {
            Text("Already have an account? ", style = MaterialTheme.typography.bodyMedium)
            Text(
                "Log In",
                color = MaterialTheme.colorScheme.primary,
                fontWeight = FontWeight.SemiBold,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.clickableText(onNavigateToLogin)
            )
        }
        Spacer(Modifier.height(24.dp))
    }
}

// Small helper so "Sign Up" / "Log In" inline text acts like a link without pulling in a
// separate annotated-string dependency.
private fun Modifier.clickableText(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
