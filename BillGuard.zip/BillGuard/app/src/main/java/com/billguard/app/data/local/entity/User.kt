package com.billguard.app.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val userId: Long = 0,
    val name: String,
    val email: String,
    val phone: String,
    // Salted SHA-256 hash - see domain/util/SecurityUtils.kt. Never stored as plaintext.
    val passwordHash: String,
    val salt: String,
    val currency: String = "INR",
    val currencySymbol: String = "\u20B9",
    val monthlySpendingTarget: Double? = null,
    val authProvider: String = "LOCAL", // LOCAL or GOOGLE (Firebase-ready, see README)
    val createdAt: Long = System.currentTimeMillis()
)
