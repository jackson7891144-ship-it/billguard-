package com.billguard.app.data.local.dao

import androidx.room.*
import com.billguard.app.data.local.entity.Reminder
import kotlinx.coroutines.flow.Flow

@Dao
interface ReminderDao {
    @Insert
    suspend fun insert(reminder: Reminder): Long

    @Update
    suspend fun update(reminder: Reminder)

    @Delete
    suspend fun delete(reminder: Reminder)

    @Query("SELECT * FROM reminders WHERE userId = :userId AND enabled = 1 ORDER BY reminderDateTime ASC")
    fun observeUpcoming(userId: Long): Flow<List<Reminder>>

    @Query("SELECT * FROM reminders WHERE subscriptionId = :subscriptionId")
    suspend fun getForSubscription(subscriptionId: Long): List<Reminder>

    @Query("SELECT * FROM reminders WHERE billId = :billId")
    suspend fun getForBill(billId: Long): List<Reminder>

    @Query("DELETE FROM reminders WHERE subscriptionId = :subscriptionId")
    suspend fun deleteForSubscription(subscriptionId: Long)

    @Query("DELETE FROM reminders WHERE billId = :billId")
    suspend fun deleteForBill(billId: Long)

    @Query("SELECT * FROM reminders WHERE enabled = 1")
    suspend fun getAllEnabled(): List<Reminder>
}
