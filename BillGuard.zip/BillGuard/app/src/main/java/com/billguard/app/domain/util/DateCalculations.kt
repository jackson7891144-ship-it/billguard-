package com.billguard.app.domain.util

import com.billguard.app.domain.Frequency
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.temporal.ChronoUnit

/**
 * All recurring-date math lives here so it is computed exactly once, correctly, using
 * java.time (not manual millisecond arithmetic) — this is what keeps month lengths, leap
 * years, and DST-safe local dates correct per section 35 of the spec.
 */
object DateCalculations {

    private val zone: ZoneId = ZoneId.systemDefault()
    private val displayFormatter = DateTimeFormatter.ofPattern("d MMM yyyy")

    fun epochToLocalDate(epochMillis: Long): LocalDate =
        Instant.ofEpochMilli(epochMillis).atZone(zone).toLocalDate()

    fun localDateToEpoch(date: LocalDate): Long =
        date.atStartOfDay(zone).toInstant().toEpochMilli()

    fun today(): LocalDate = LocalDate.now(zone)

    fun formatDate(epochMillis: Long): String = epochToLocalDate(epochMillis).format(displayFormatter)

    /** Days remaining until [epochMillis], can be negative if the date is in the past (overdue). */
    fun daysRemaining(epochMillis: Long): Long =
        ChronoUnit.DAYS.between(today(), epochToLocalDate(epochMillis))

    /**
     * Advances [fromDate] by one billing cycle of [frequency]. For CUSTOM, [customDays] is used.
     * Uses calendar-aware plusWeeks/plusMonths/plusYears so "31 Jan monthly" correctly lands on
     * the last day of shorter months instead of silently drifting.
     */
    fun advance(fromDate: LocalDate, frequency: Frequency, customDays: Long = 30): LocalDate = when (frequency) {
        Frequency.WEEKLY -> fromDate.plusWeeks(1)
        Frequency.MONTHLY -> fromDate.plusMonths(1)
        Frequency.QUARTERLY -> fromDate.plusMonths(3)
        Frequency.HALF_YEARLY -> fromDate.plusMonths(6)
        Frequency.YEARLY -> fromDate.plusYears(1)
        Frequency.CUSTOM -> fromDate.plusDays(customDays)
    }

    /** Rolls [renewalDate] forward past today, one cycle at a time, to find the *next* real renewal. */
    fun nextRenewalOnOrAfterToday(renewalDate: LocalDate, frequency: Frequency, customDays: Long = 30): LocalDate {
        var next = renewalDate
        var guard = 0
        while (next.isBefore(today()) && guard < 2000) {
            next = advance(next, frequency, customDays)
            guard++
        }
        return next
    }

    /** How many of this cycle occur per calendar year, for monthly/yearly spending projections. */
    fun cyclesPerYear(frequency: Frequency, customDays: Long = 30): Double = when (frequency) {
        Frequency.WEEKLY -> 52.0
        Frequency.MONTHLY -> 12.0
        Frequency.QUARTERLY -> 4.0
        Frequency.HALF_YEARLY -> 2.0
        Frequency.YEARLY -> 1.0
        Frequency.CUSTOM -> 365.0 / customDays.coerceAtLeast(1)
    }
}
