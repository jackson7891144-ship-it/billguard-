package com.billguard.app.data.local.dao

import androidx.room.*
import com.billguard.app.data.local.entity.NotificationEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface NotificationDao {
    @Insert
    suspend fun insert(notification: NotificationEntity): Long

    @Update
    suspend fun update(notification: NotificationEntity)

    @Delete
    suspend fun delete(notification: NotificationEntity)

    @Query("SELECT * FROM notifications WHERE userId = :userId ORDER BY createdAt DESC")
    fun observeAll(userId: Long): Flow<List<NotificationEntity>>

    @Query("SELECT COUNT(*) FROM notifications WHERE userId = :userId AND readStatus = 0")
    fun observeUnreadCount(userId: Long): Flow<Int>

    @Query("UPDATE notifications SET readStatus = 1 WHERE notificationId = :id")
    suspend fun markRead(id: Long)

    @Query("UPDATE notifications SET readStatus = 1 WHERE userId = :userId")
    suspend fun markAllRead(userId: Long)
}
