package com.billguard.app.domain.util

import com.billguard.app.data.local.entity.Bill
import com.billguard.app.data.local.entity.Subscription
import com.billguard.app.domain.Frequency

data class SpendingSummary(
    val monthlyTotal: Double,
    val yearlyTotal: Double,
    val categoryBreakdown: Map<String, Double>, // category label -> monthly amount
    val mostExpensiveName: String?,
    val mostExpensiveMonthly: Double
)

data class UpcomingItem(
    val name: String,
    val amount: Double,
    val currencySymbol: String,
    val dueEpochMillis: Long,
    val daysRemaining: Long,
    val autopay: Boolean,
    val isSubscription: Boolean,
    val id: Long
)

/**
 * Every number here is derived strictly from the subscriptions/bills actually stored in Room —
 * nothing is invented, matching the "never fabricate financial information" requirement.
 */
object SpendingCalculator {

    private fun freqOf(value: String): Frequency =
        runCatching { Frequency.valueOf(value) }.getOrDefault(Frequency.MONTHLY)

    private fun monthly(amount: Double, frequency: Frequency): Double =
        amount * DateCalculations.cyclesPerYear(frequency) / 12.0

    fun summarize(subscriptions: List<Subscription>, bills: List<Bill>): SpendingSummary {
        val activeSubs = subscriptions.filter { it.status == "ACTIVE" || it.status == "TRIAL" }
        val activeBills = bills.filter { it.status == "ACTIVE" }

        val breakdown = mutableMapOf<String, Double>()
        var monthlyTotal = 0.0
        var mostExpensiveName: String? = null
        var mostExpensiveMonthly = 0.0

        for (s in activeSubs) {
            val m = monthly(s.amount, freqOf(s.frequency))
            monthlyTotal += m
            breakdown[s.category] = (breakdown[s.category] ?: 0.0) + m
            if (m > mostExpensiveMonthly) { mostExpensiveMonthly = m; mostExpensiveName = s.name }
        }
        for (b in activeBills) {
            val m = monthly(b.amount, freqOf(b.frequency))
            monthlyTotal += m
            breakdown[b.category] = (breakdown[b.category] ?: 0.0) + m
            if (m > mostExpensiveMonthly) { mostExpensiveMonthly = m; mostExpensiveName = b.name }
        }

        return SpendingSummary(
            monthlyTotal = monthlyTotal,
            yearlyTotal = monthlyTotal * 12.0,
            categoryBreakdown = breakdown,
            mostExpensiveName = mostExpensiveName,
            mostExpensiveMonthly = mostExpensiveMonthly
        )
    }

    /** Items (name, amount, epoch due date, autopay) renewing/due within [days] days from today, soonest first. */
    fun upcomingWithinDays(
        subscriptions: List<Subscription>,
        bills: List<Bill>,
        days: Long
    ): List<UpcomingItem> {
        val items = mutableListOf<UpcomingItem>()
        for (s in subscriptions.filter { it.status == "ACTIVE" || it.status == "TRIAL" }) {
            val remaining = DateCalculations.daysRemaining(s.renewalDate)
            if (remaining in 0..days) {
                items.add(UpcomingItem(s.name, s.amount, s.currencySymbol, s.renewalDate, remaining, s.autopay, isSubscription = true, id = s.subscriptionId))
            }
        }
        for (b in bills.filter { it.status == "ACTIVE" }) {
            val remaining = DateCalculations.daysRemaining(b.dueDate)
            if (remaining in 0..days) {
                items.add(UpcomingItem(b.name, b.amount, b.currencySymbol, b.dueDate, remaining, b.autopay, isSubscription = false, id = b.billId))
            }
        }
        return items.sortedBy { it.daysRemaining }
    }
}
