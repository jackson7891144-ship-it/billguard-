package com.billguard.app.ui.subscriptions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.Subscription
import com.billguard.app.domain.util.DateCalculations
import com.billguard.app.ui.components.ChipTone
import com.billguard.app.ui.components.EmptyState
import com.billguard.app.ui.components.SectionCard
import com.billguard.app.ui.components.StatusChip
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class SubscriptionsViewModel(private val container: AppContainer, private val userId: Long) : ViewModel() {
    private val _subscriptions = MutableStateFlow<List<Subscription>>(emptyList())
    val subscriptions: StateFlow<List<Subscription>> = _subscriptions

    init {
        viewModelScope.launch {
            container.subscriptionRepository.observeAll(userId).collectLatest { _subscriptions.value = it }
        }
    }
}

@Composable
fun SubscriptionsListScreen(
    viewModel: SubscriptionsViewModel,
    onAdd: () -> Unit,
    onOpen: (Long) -> Unit
) {
    val subscriptions by viewModel.subscriptions.collectAsState()
    val active = subscriptions.filter { it.status != "CANCELLED" }

    if (active.isEmpty()) {
        EmptyState(
            title = "No subscriptions yet.",
            subtitle = "Add your first subscription and let BillGuard track the renewal.",
            actionLabel = "+ Add Subscription",
            onAction = onAdd
        )
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Subscriptions", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        items(active, key = { it.subscriptionId }) { sub ->
            SectionCard(onClick = { onOpen(sub.subscriptionId) }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(sub.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                        Text(sub.provider.ifBlank { sub.category }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                        Text("${sub.currencySymbol}${"%.0f".format(sub.amount)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        val days = DateCalculations.daysRemaining(sub.renewalDate)
                        StatusChip(
                            label = if (sub.isTrial) "Trial · ${days}d" else "${days}d left",
                            tone = when {
                                days <= 1 -> ChipTone.ERROR
                                days <= 3 -> ChipTone.WARNING
                                sub.autopay -> ChipTone.SUCCESS
                                else -> ChipTone.NEUTRAL
                            }
                        )
                    }
                }
            }
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}
