package com.billguard.app.ui.dashboard

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.Bill
import com.billguard.app.data.local.entity.Subscription
import com.billguard.app.data.local.entity.User
import com.billguard.app.domain.util.SpendingCalculator
import com.billguard.app.domain.util.SpendingSummary
import com.billguard.app.domain.util.UpcomingItem
import com.billguard.app.ui.components.SectionCard
import com.billguard.app.ui.components.SpendingProgressBar
import com.billguard.app.ui.components.StatusChip
import com.billguard.app.ui.components.ChipTone
import com.billguard.app.ui.components.UltronCard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class DashboardUiState(
    val user: User? = null,
    val summary: SpendingSummary = SpendingSummary(0.0, 0.0, emptyMap(), null, 0.0),
    val upcoming: List<UpcomingItem> = emptyList(),
    val activeSubscriptionCount: Int = 0,
    val trialCount: Int = 0,
    val autopayCount: Int = 0,
    val ultronMessage: String = "Good day. Add your first subscription so I can start watching it for you.",
    val ultronWarning: Boolean = false
)

class DashboardViewModel(private val container: AppContainer, private val userId: Long) : ViewModel() {
    private val _state = MutableStateFlow(DashboardUiState())
    val state: StateFlow<DashboardUiState> = _state

    init {
        viewModelScope.launch {
            combine(
                container.userRepository.observeUser(userId),
                container.subscriptionRepository.observeAll(userId),
                container.billRepository.observeAll(userId)
            ) { user, subs, bills -> Triple(user, subs, bills) }
                .collectLatest { (user, subs, bills) -> applyData(user, subs, bills) }
        }
    }

    private fun applyData(user: User?, subs: List<Subscription>, bills: List<Bill>) {
        val summary = SpendingCalculator.summarize(subs, bills)
        val upcoming = SpendingCalculator.upcomingWithinDays(subs, bills, 30)
        val activeSubs = subs.count { it.status == "ACTIVE" || it.status == "TRIAL" }
        val trials = subs.count { it.isTrial }
        val autopay = subs.count { it.autopay && (it.status == "ACTIVE" || it.status == "TRIAL") } + bills.count { it.autopay && it.status == "ACTIVE" }

        val weekly = upcoming.filter { it.daysRemaining <= 7 }
        val symbol = user?.currencySymbol ?: "\u20B9"
        val (message, warning) = when {
            user != null && user.monthlySpendingTarget != null && summary.monthlyTotal > user.monthlySpendingTarget ->
                "Your recurring subscription spending has exceeded your monthly target of $symbol${"%.0f".format(user.monthlySpendingTarget)}." to true
            weekly.isNotEmpty() -> {
                val next = weekly.first()
                val total = weekly.sumOf { it.amount }
                "Good day. You have ${weekly.size} upcoming payment${if (weekly.size == 1) "" else "s"} this week totaling $symbol${"%.0f".format(total)}. Your next payment is ${next.name} — $symbol${"%.0f".format(next.amount)} in ${next.daysRemaining} day${if (next.daysRemaining == 1L) "" else "s"}." to false
            }
            subs.isEmpty() && bills.isEmpty() -> "Good day. Add your first subscription so I can start watching it for you." to false
            else -> "Good day. Nothing is due in the next 7 days — you're all clear for now." to false
        }

        _state.value = DashboardUiState(
            user = user,
            summary = summary,
            upcoming = upcoming.take(10),
            activeSubscriptionCount = activeSubs,
            trialCount = trials,
            autopayCount = autopay,
            ultronMessage = message,
            ultronWarning = warning
        )
    }
}

@Composable
fun DashboardScreen(
    viewModel: DashboardViewModel,
    onOpenSubscription: (Long) -> Unit,
    onOpenBill: (Long) -> Unit,
    onOpenAnalytics: () -> Unit
) {
    val state by viewModel.state.collectAsState()
    val symbol = state.user?.currencySymbol ?: "\u20B9"

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("Hi${state.user?.name?.let { ", ${it.split(" ").first()}" } ?: ""}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }

        item { UltronCard(state.ultronMessage, isWarning = state.ultronWarning) }

        item {
            SectionCard {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Monthly Spending", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$symbol${"%.0f".format(state.summary.monthlyTotal)}", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    }
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                        Text("Yearly Projection", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("$symbol${"%.0f".format(state.summary.yearlyTotal)}", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(16.dp))
                SpendingProgressBar(
                    current = state.summary.monthlyTotal,
                    target = state.user?.monthlySpendingTarget ?: 0.0,
                    symbol = symbol
                )
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatTile("Active", state.activeSubscriptionCount.toString(), Modifier.weight(1f))
                StatTile("Trials Ending", state.trialCount.toString(), Modifier.weight(1f))
                StatTile("Autopay", state.autopayCount.toString(), Modifier.weight(1f))
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("Upcoming Payments", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("Analytics ›", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.then(androidx.compose.ui.Modifier).let { it }
                )
            }
        }

        if (state.upcoming.isEmpty()) {
            item {
                SectionCard { Text("Nothing due in the next 30 days.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
            }
        } else {
            items(state.upcoming) { item ->
                SectionCard(onClick = { if (item.isSubscription) onOpenSubscription(item.id) else onOpenBill(item.id) }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column {
                            Text(item.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                            Text(
                                "${item.currencySymbol.ifBlank { symbol }}${"%.2f".format(item.amount)}",
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        val tone = when {
                            item.daysRemaining <= 1 -> ChipTone.ERROR
                            item.daysRemaining <= 3 -> ChipTone.WARNING
                            else -> ChipTone.NEUTRAL
                        }
                        StatusChip(
                            label = if (item.daysRemaining == 0L) "Today" else "${item.daysRemaining}d left",
                            tone = tone
                        )
                    }
                }
            }
        }

        item { Spacer(Modifier.height(70.dp)) } // room for the FAB
    }
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier = Modifier) {
    SectionCard(modifier = modifier) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
