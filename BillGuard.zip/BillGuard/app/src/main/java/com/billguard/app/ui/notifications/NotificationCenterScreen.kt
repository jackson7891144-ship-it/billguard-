package com.billguard.app.ui.notifications

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.NotificationEntity
import com.billguard.app.domain.util.DateCalculations
import com.billguard.app.ui.components.EmptyState
import com.billguard.app.ui.components.SectionCard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class NotificationsViewModel(private val container: AppContainer, private val userId: Long) : ViewModel() {
    private val _notifications = MutableStateFlow<List<NotificationEntity>>(emptyList())
    val notifications: StateFlow<List<NotificationEntity>> = _notifications

    init {
        viewModelScope.launch {
            container.notificationRepository.observeAll(userId).collectLatest { _notifications.value = it }
        }
    }

    fun markRead(id: Long) { viewModelScope.launch { container.notificationRepository.markRead(id) } }
    fun markAllRead() { viewModelScope.launch { container.notificationRepository.markAllRead(userId) } }
    fun delete(notification: NotificationEntity) { viewModelScope.launch { container.notificationRepository.delete(notification) } }
}

@Composable
fun NotificationCenterScreen(
    viewModel: NotificationsViewModel,
    onOpenSubscription: (Long) -> Unit,
    onOpenBill: (Long) -> Unit
) {
    val notifications by viewModel.notifications.collectAsState()

    if (notifications.isEmpty()) {
        EmptyState(
            title = "No notifications yet.",
            subtitle = "ULTRON will post reminders and insights here as your renewal dates approach.",
            actionLabel = "Got it",
            onAction = {}
        )
        return
    }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Notifications", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            TextButton(onClick = { viewModel.markAllRead() }) { Text("Mark all read") }
        }

        LazyColumn(contentPadding = PaddingValues(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(notifications, key = { it.notificationId }) { n ->
                SectionCard(onClick = {
                    viewModel.markRead(n.notificationId)
                    n.relatedSubscriptionId?.let { onOpenSubscription(it) }
                    n.relatedBillId?.let { onOpenBill(it) }
                }) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Column(Modifier.weight(1f)) {
                            Text(n.title, style = MaterialTheme.typography.titleMedium, fontWeight = if (n.readStatus) FontWeight.Normal else FontWeight.Bold)
                            Spacer(Modifier.height(2.dp))
                            Text(n.message, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(4.dp))
                            Text(DateCalculations.formatDate(n.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { viewModel.delete(n) }) {
                            Icon(androidx.compose.material.icons.Icons.Filled.Close, contentDescription = "Dismiss")
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(70.dp)) }
        }
    }
}
