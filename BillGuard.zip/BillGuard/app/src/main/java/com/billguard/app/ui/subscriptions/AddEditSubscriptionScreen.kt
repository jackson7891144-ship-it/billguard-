package com.billguard.app.ui.subscriptions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.PaymentMethod
import com.billguard.app.data.local.entity.Subscription
import com.billguard.app.domain.ReminderOffset
import com.billguard.app.domain.SubscriptionCategory
import com.billguard.app.domain.Frequency
import com.billguard.app.domain.util.DateCalculations
import com.billguard.app.domain.util.Validators
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

data class SubscriptionFormState(
    val name: String = "",
    val provider: String = "",
    val category: SubscriptionCategory = SubscriptionCategory.OTHER,
    val amount: String = "",
    val frequency: Frequency = Frequency.MONTHLY,
    val startDate: LocalDate = DateCalculations.today(),
    val renewalDate: LocalDate = DateCalculations.today().plusMonths(1),
    val isTrial: Boolean = false,
    val trialEnd: LocalDate = DateCalculations.today().plusDays(7),
    val postTrialAmount: String = "",
    val autopay: Boolean = true,
    val paymentMethodId: Long? = null,
    val reminderOffsets: Set<ReminderOffset> = setOf(ReminderOffset.SEVEN_DAYS, ReminderOffset.THREE_DAYS, ReminderOffset.ONE_DAY, ReminderOffset.SAME_DAY),
    val notes: String = "",
    val errorMessage: String? = null,
    val paymentMethods: List<PaymentMethod> = emptyList(),
    val currencySymbol: String = "\u20B9",
    val isEditing: Boolean = false,
    val saved: Boolean = false
)

class AddEditSubscriptionViewModel(
    private val container: AppContainer,
    private val userId: Long,
    private val subscriptionId: Long?
) : ViewModel() {

    private val _state = MutableStateFlow(SubscriptionFormState(isEditing = subscriptionId != null))
    val state: StateFlow<SubscriptionFormState> = _state

    init {
        viewModelScope.launch {
            val user = container.userRepository.getUser(userId)
            _state.value = _state.value.copy(currencySymbol = user?.currencySymbol ?: "\u20B9")

            if (subscriptionId != null) {
                container.subscriptionRepository.getById(subscriptionId)?.let { s ->
                    _state.value = _state.value.copy(
                        name = s.name,
                        provider = s.provider,
                        category = runCatching { SubscriptionCategory.valueOf(s.category) }.getOrDefault(SubscriptionCategory.OTHER),
                        amount = s.amount.toString(),
                        frequency = runCatching { Frequency.valueOf(s.frequency) }.getOrDefault(Frequency.MONTHLY),
                        startDate = DateCalculations.epochToLocalDate(s.startDate),
                        renewalDate = DateCalculations.epochToLocalDate(s.renewalDate),
                        isTrial = s.isTrial,
                        trialEnd = s.trialEnd?.let { DateCalculations.epochToLocalDate(it) } ?: DateCalculations.today().plusDays(7),
                        postTrialAmount = s.postTrialAmount?.toString() ?: "",
                        autopay = s.autopay,
                        paymentMethodId = s.paymentMethodId,
                        reminderOffsets = s.reminderOffsets.split(",").mapNotNull { r -> runCatching { ReminderOffset.valueOf(r) }.getOrNull() }.toSet(),
                        notes = s.notes,
                        currencySymbol = s.currencySymbol
                    )
                }
            }
        }
    }

    fun update(transform: (SubscriptionFormState) -> SubscriptionFormState) {
        _state.value = transform(_state.value).copy(errorMessage = null)
    }

    fun save() {
        val s = _state.value
        if (!Validators.isNotBlank(s.name)) { setError("Enter a subscription name."); return }
        if (!Validators.isValidAmount(s.amount)) { setError("Enter a valid amount."); return }

        viewModelScope.launch {
            val entity = Subscription(
                subscriptionId = subscriptionId ?: 0,
                userId = userId,
                name = s.name.trim(),
                provider = s.provider.trim(),
                category = s.category.name,
                amount = s.amount.toDouble(),
                currencySymbol = s.currencySymbol,
                frequency = s.frequency.name,
                startDate = DateCalculations.localDateToEpoch(s.startDate),
                renewalDate = DateCalculations.localDateToEpoch(s.renewalDate),
                isTrial = s.isTrial,
                trialStart = if (s.isTrial) DateCalculations.localDateToEpoch(s.startDate) else null,
                trialEnd = if (s.isTrial) DateCalculations.localDateToEpoch(s.trialEnd) else null,
                postTrialAmount = s.postTrialAmount.toDoubleOrNull(),
                paymentMethodId = s.paymentMethodId,
                autopay = s.autopay,
                status = if (s.isTrial) "TRIAL" else "ACTIVE",
                reminderOffsets = s.reminderOffsets.joinToString(",") { it.name },
                notes = s.notes.trim()
            )
            val id = if (subscriptionId != null) {
                container.subscriptionRepository.update(entity); subscriptionId
            } else {
                container.subscriptionRepository.add(entity)
            }
            rescheduleReminders(id, entity)
            _state.value = _state.value.copy(saved = true)
        }
    }

    private suspend fun rescheduleReminders(subscriptionId: Long, entity: Subscription) {
        // Cancel any previous reminders for this item, then create fresh ones from the chosen offsets.
        val existing = container.reminderRepository.getForSubscription(subscriptionId)
        existing.forEach { com.billguard.app.reminder.ReminderScheduler.cancel(getAppContext(), it) }
        container.reminderRepository.deleteForSubscription(subscriptionId)

        val targetDate = if (entity.isTrial && entity.trialEnd != null) entity.trialEnd else entity.renewalDate
        _state.value.reminderOffsets.forEach { offset ->
            val fireEpoch = targetDate - (offset.daysBefore * 24L * 60 * 60 * 1000)
            if (fireEpoch > System.currentTimeMillis()) {
                val reminder = com.billguard.app.data.local.entity.Reminder(
                    userId = userId,
                    subscriptionId = subscriptionId,
                    itemName = entity.name,
                    reminderDateTime = fireEpoch,
                    reminderType = offset.name,
                    alarmRequestCode = (subscriptionId * 100 + offset.daysBefore).toInt()
                )
                val id = container.reminderRepository.add(reminder)
                com.billguard.app.reminder.ReminderScheduler.schedule(getAppContext(), reminder.copy(reminderId = id))
            }
        }
    }

    // The container doesn't carry a Context; ReminderScheduler only needs it briefly to reach
    // AlarmManager, so we grab it via the same process-wide Application instance.
    private fun getAppContext() = com.billguard.app.BillGuardAppRef.appContext

    private fun setError(message: String) { _state.value = _state.value.copy(errorMessage = message) }
}

@Composable
fun AddEditSubscriptionScreen(viewModel: AddEditSubscriptionViewModel, onSaved: () -> Unit) {
    val state by viewModel.state.collectAsState()
    LaunchedEffect(state.saved) { if (state.saved) onSaved() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(if (state.isEditing) "Edit Subscription" else "Add Subscription", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(state.name, { v -> viewModel.update { it.copy(name = v) } }, label = { Text("Subscription Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(state.provider, { v -> viewModel.update { it.copy(provider = v) } }, label = { Text("Provider") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))

        EnumDropdown("Category", SubscriptionCategory.values().toList(), state.category, { it.label }) { viewModel.update { s -> s.copy(category = it) } }
        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            state.amount, { v -> viewModel.update { it.copy(amount = v) } },
            label = { Text("Amount (${state.currencySymbol})") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Spacer(Modifier.height(10.dp))

        EnumDropdown("Billing Frequency", Frequency.values().toList(), state.frequency, { it.label }) { viewModel.update { s -> s.copy(frequency = it) } }
        Spacer(Modifier.height(10.dp))

        DatePickerField("Start Date", state.startDate) { viewModel.update { s -> s.copy(startDate = it) } }
        Spacer(Modifier.height(10.dp))
        DatePickerField("Renewal Date", state.renewalDate) { viewModel.update { s -> s.copy(renewalDate = it) } }
        Spacer(Modifier.height(14.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Free Trial", style = MaterialTheme.typography.titleMedium)
            Switch(state.isTrial, { v -> viewModel.update { it.copy(isTrial = v) } })
        }
        if (state.isTrial) {
            Spacer(Modifier.height(6.dp))
            DatePickerField("Trial End Date", state.trialEnd) { viewModel.update { s -> s.copy(trialEnd = it) } }
            Spacer(Modifier.height(10.dp))
            OutlinedTextField(
                state.postTrialAmount, { v -> viewModel.update { it.copy(postTrialAmount = v) } },
                label = { Text("Amount After Trial (${state.currencySymbol})") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                modifier = Modifier.fillMaxWidth(), singleLine = true
            )
        }

        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("Autopay", style = MaterialTheme.typography.titleMedium)
                Text("Automatic payment on the renewal date if enabled.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Switch(state.autopay, { v -> viewModel.update { it.copy(autopay = v) } })
        }

        Spacer(Modifier.height(16.dp))
        Text("Remind Me", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ReminderOffset.values().forEach { offset ->
                FilterChip(
                    selected = offset in state.reminderOffsets,
                    onClick = {
                        viewModel.update {
                            val newSet = if (offset in it.reminderOffsets) it.reminderOffsets - offset else it.reminderOffsets + offset
                            it.copy(reminderOffsets = newSet)
                        }
                    },
                    label = { Text(offset.label) }
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        OutlinedTextField(state.notes, { v -> viewModel.update { it.copy(notes = v) } }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

        state.errorMessage?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(20.dp))
        Button(onClick = { viewModel.save() }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
            Text(if (state.isEditing) "Save Changes" else "Add Subscription")
        }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
fun <T> EnumDropdown(label: String, options: List<T>, selected: T, labelOf: (T) -> String, onSelect: (T) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedTextField(
            value = labelOf(selected),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { Icon(Icons.Filled.CalendarMonth, contentDescription = null) },
            modifier = Modifier.fillMaxWidth().let { it },
        )
        Box(
            modifier = Modifier
                .matchParentSize()
                .clickableNoRipple { expanded = true }
        )
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option ->
                DropdownMenuItem(text = { Text(labelOf(option)) }, onClick = { onSelect(option); expanded = false })
            }
        }
    }
}

@Composable
fun DatePickerField(label: String, date: LocalDate, onDateSelected: (LocalDate) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    Box(modifier = Modifier.fillMaxWidth()) {
        OutlinedTextField(
            value = DateCalculations.formatDate(DateCalculations.localDateToEpoch(date)),
            onValueChange = {},
            readOnly = true,
            label = { Text(label) },
            trailingIcon = { Icon(Icons.Filled.CalendarMonth, contentDescription = "Pick date") },
            modifier = Modifier.fillMaxWidth()
        )
        Box(modifier = Modifier.matchParentSize().clickableNoRipple { showDialog = true })
    }

    if (showDialog) {
        val pickerState = rememberDatePickerState(initialSelectedDateMillis = DateCalculations.localDateToEpoch(date))
        DatePickerDialog(
            onDismissRequest = { showDialog = false },
            confirmButton = {
                TextButton(onClick = {
                    pickerState.selectedDateMillis?.let { onDateSelected(DateCalculations.epochToLocalDate(it)) }
                    showDialog = false
                }) { Text("OK") }
            },
            dismissButton = { TextButton(onClick = { showDialog = false }) { Text("Cancel") } }
        ) { DatePicker(state = pickerState) }
    }
}

private fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))
