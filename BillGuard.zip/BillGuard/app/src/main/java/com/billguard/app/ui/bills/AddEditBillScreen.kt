package com.billguard.app.ui.bills

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.Bill
import com.billguard.app.data.local.entity.Reminder
import com.billguard.app.domain.BillCategory
import com.billguard.app.domain.Frequency
import com.billguard.app.domain.ReminderOffset
import com.billguard.app.domain.util.DateCalculations
import com.billguard.app.domain.util.Validators
import com.billguard.app.reminder.ReminderScheduler
import com.billguard.app.ui.subscriptions.DatePickerField
import com.billguard.app.ui.subscriptions.EnumDropdown
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.time.LocalDate

data class BillFormState(
    val name: String = "",
    val provider: String = "",
    val category: BillCategory = BillCategory.OTHER,
    val amount: String = "",
    val frequency: Frequency = Frequency.MONTHLY,
    val dueDate: LocalDate = DateCalculations.today().plusDays(7),
    val autopay: Boolean = false,
    val reminderOffsets: Set<ReminderOffset> = setOf(ReminderOffset.SEVEN_DAYS, ReminderOffset.THREE_DAYS, ReminderOffset.ONE_DAY, ReminderOffset.SAME_DAY),
    val notes: String = "",
    val errorMessage: String? = null,
    val currencySymbol: String = "\u20B9",
    val isEditing: Boolean = false,
    val saved: Boolean = false
)

class AddEditBillViewModel(
    private val container: AppContainer,
    private val userId: Long,
    private val billId: Long?
) : ViewModel() {

    private val _state = MutableStateFlow(BillFormState(isEditing = billId != null))
    val state: StateFlow<BillFormState> = _state

    init {
        viewModelScope.launch {
            val user = container.userRepository.getUser(userId)
            _state.value = _state.value.copy(currencySymbol = user?.currencySymbol ?: "\u20B9")

            if (billId != null) {
                container.billRepository.getById(billId)?.let { b ->
                    _state.value = _state.value.copy(
                        name = b.name,
                        provider = b.provider,
                        category = runCatching { BillCategory.valueOf(b.category) }.getOrDefault(BillCategory.OTHER),
                        amount = b.amount.toString(),
                        frequency = runCatching { Frequency.valueOf(b.frequency) }.getOrDefault(Frequency.MONTHLY),
                        dueDate = DateCalculations.epochToLocalDate(b.dueDate),
                        autopay = b.autopay,
                        reminderOffsets = b.reminderOffsets.split(",").mapNotNull { r -> runCatching { ReminderOffset.valueOf(r) }.getOrNull() }.toSet(),
                        notes = b.notes,
                        currencySymbol = b.currencySymbol
                    )
                }
            }
        }
    }

    fun update(transform: (BillFormState) -> BillFormState) {
        _state.value = transform(_state.value).copy(errorMessage = null)
    }

    fun save() {
        val s = _state.value
        if (!Validators.isNotBlank(s.name)) { _state.value = s.copy(errorMessage = "Enter a bill name."); return }
        if (!Validators.isValidAmount(s.amount)) { _state.value = s.copy(errorMessage = "Enter a valid amount."); return }

        viewModelScope.launch {
            val entity = Bill(
                billId = billId ?: 0,
                userId = userId,
                name = s.name.trim(),
                provider = s.provider.trim(),
                category = s.category.name,
                amount = s.amount.toDouble(),
                currencySymbol = s.currencySymbol,
                frequency = s.frequency.name,
                dueDate = DateCalculations.localDateToEpoch(s.dueDate),
                autopay = s.autopay,
                status = "ACTIVE",
                reminderOffsets = s.reminderOffsets.joinToString(",") { it.name },
                notes = s.notes.trim()
            )
            val id = if (billId != null) { container.billRepository.update(entity); billId } else container.billRepository.add(entity)
            rescheduleReminders(id, entity)
            _state.value = _state.value.copy(saved = true)
        }
    }

    private suspend fun rescheduleReminders(billId: Long, entity: Bill) {
        val existing = container.reminderRepository.getForBill(billId)
        existing.forEach { ReminderScheduler.cancel(com.billguard.app.BillGuardAppRef.appContext, it) }
        container.reminderRepository.deleteForBill(billId)

        _state.value.reminderOffsets.forEach { offset ->
            val fireEpoch = entity.dueDate - (offset.daysBefore * 24L * 60 * 60 * 1000)
            if (fireEpoch > System.currentTimeMillis()) {
                val reminder = Reminder(
                    userId = userId, billId = billId, itemName = entity.name,
                    reminderDateTime = fireEpoch, reminderType = offset.name,
                    alarmRequestCode = (billId * 100 + offset.daysBefore).toInt() + 500_000
                )
                val id = container.reminderRepository.add(reminder)
                ReminderScheduler.schedule(com.billguard.app.BillGuardAppRef.appContext, reminder.copy(reminderId = id))
            }
        }
    }
}

@Composable
fun AddEditBillScreen(viewModel: AddEditBillViewModel, onSaved: () -> Unit) {
    val state by viewModel.state.collectAsState()
    LaunchedEffect(state.saved) { if (state.saved) onSaved() }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text(if (state.isEditing) "Edit Bill" else "Add Recurring Bill", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(state.name, { v -> viewModel.update { it.copy(name = v) } }, label = { Text("Bill Name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(state.provider, { v -> viewModel.update { it.copy(provider = v) } }, label = { Text("Provider") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(10.dp))

        EnumDropdown("Category", BillCategory.values().toList(), state.category, { it.label }) { viewModel.update { s -> s.copy(category = it) } }
        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            state.amount, { v -> viewModel.update { it.copy(amount = v) } },
            label = { Text("Amount (${state.currencySymbol})") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
            modifier = Modifier.fillMaxWidth(), singleLine = true
        )
        Spacer(Modifier.height(10.dp))

        EnumDropdown("Frequency", Frequency.values().toList(), state.frequency, { it.label }) { viewModel.update { s -> s.copy(frequency = it) } }
        Spacer(Modifier.height(10.dp))

        DatePickerField("Due Date", state.dueDate) { viewModel.update { s -> s.copy(dueDate = it) } }
        Spacer(Modifier.height(14.dp))

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Autopay", style = MaterialTheme.typography.titleMedium)
            Switch(state.autopay, { v -> viewModel.update { it.copy(autopay = v) } })
        }

        Spacer(Modifier.height(16.dp))
        Text("Remind Me", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            ReminderOffset.values().forEach { offset ->
                FilterChip(
                    selected = offset in state.reminderOffsets,
                    onClick = {
                        viewModel.update {
                            val newSet = if (offset in it.reminderOffsets) it.reminderOffsets - offset else it.reminderOffsets + offset
                            it.copy(reminderOffsets = newSet)
                        }
                    },
                    label = { Text(offset.label) }
                )
            }
        }

        Spacer(Modifier.height(14.dp))
        OutlinedTextField(state.notes, { v -> viewModel.update { it.copy(notes = v) } }, label = { Text("Notes") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

        state.errorMessage?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(20.dp))
        Button(onClick = { viewModel.save() }, modifier = Modifier.fillMaxWidth().height(50.dp)) {
            Text(if (state.isEditing) "Save Changes" else "Add Bill")
        }
        Spacer(Modifier.height(24.dp))
    }
}
