package com.billguard.app.data.local.dao

import androidx.room.*
import com.billguard.app.data.local.entity.Subscription
import kotlinx.coroutines.flow.Flow

@Dao
interface SubscriptionDao {
    @Insert
    suspend fun insert(subscription: Subscription): Long

    @Update
    suspend fun update(subscription: Subscription)

    @Delete
    suspend fun delete(subscription: Subscription)

    @Query("SELECT * FROM subscriptions WHERE userId = :userId ORDER BY renewalDate ASC")
    fun observeAll(userId: Long): Flow<List<Subscription>>

    @Query("SELECT * FROM subscriptions WHERE userId = :userId AND status = 'ACTIVE' ORDER BY renewalDate ASC")
    fun observeActive(userId: Long): Flow<List<Subscription>>

    @Query("SELECT * FROM subscriptions WHERE subscriptionId = :id LIMIT 1")
    fun observeById(id: Long): Flow<Subscription?>

    @Query("SELECT * FROM subscriptions WHERE subscriptionId = :id LIMIT 1")
    suspend fun getById(id: Long): Subscription?

    @Query("SELECT * FROM subscriptions WHERE userId = :userId AND isTrial = 1 AND status != 'CANCELLED' ORDER BY trialEnd ASC")
    fun observeTrials(userId: Long): Flow<List<Subscription>>

    @Query("SELECT * FROM subscriptions WHERE userId = :userId AND autopay = 1 AND status = 'ACTIVE'")
    fun observeAutopay(userId: Long): Flow<List<Subscription>>

    @Query("SELECT * FROM subscriptions WHERE userId = :userId AND status = 'ACTIVE'")
    suspend fun getActiveOnce(userId: Long): List<Subscription>

    @Query(
        """SELECT * FROM subscriptions WHERE userId = :userId AND status = 'ACTIVE'
           AND (name LIKE '%' || :query || '%' OR provider LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%')"""
    )
    fun search(userId: Long, query: String): Flow<List<Subscription>>
}
