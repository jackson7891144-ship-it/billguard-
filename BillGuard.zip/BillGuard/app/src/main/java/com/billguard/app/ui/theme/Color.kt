package com.billguard.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand green
val BrandGreen = Color(0xFF1FAA59)
val BrandGreenDark = Color(0xFF12793D)
val BrandGreenTint = Color(0xFFE6F7EC)

// Light scheme: white + green
val LightBackground = Color(0xFFFFFFFF)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F7F3)
val LightOnBackground = Color(0xFF111614)
val LightOnSurfaceVariant = Color(0xFF4B5A52)
val LightOutline = Color(0xFFD8E3DC)

// Dark scheme: black + gray, green kept only as a small accent
val DarkBackground = Color(0xFF000000)
val DarkSurface = Color(0xFF1C1C1C)
val DarkSurfaceVariant = Color(0xFF2A2A2A)
val DarkOnBackground = Color(0xFFEDEDED)
val DarkOnSurfaceVariant = Color(0xFFB3B3B3)
val DarkGrayAccent = Color(0xFF6E6E6E)
val DarkOutline = Color(0xFF3A3A3A)

// Status
val StatusError = Color(0xFFD93025)
val StatusWarning = Color(0xFFF2A93B)
val StatusSuccess = BrandGreen
