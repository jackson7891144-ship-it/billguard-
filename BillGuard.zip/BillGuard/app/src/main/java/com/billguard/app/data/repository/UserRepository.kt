package com.billguard.app.data.repository

import com.billguard.app.data.local.dao.UserDao
import com.billguard.app.data.local.entity.User
import com.billguard.app.domain.util.SecurityUtils
import kotlinx.coroutines.flow.Flow

class UserRepository(private val userDao: UserDao) {

    sealed class AuthResult {
        data class Success(val user: User) : AuthResult()
        object EmailAlreadyExists : AuthResult()
        object InvalidCredentials : AuthResult()
        object UserNotFound : AuthResult()
    }

    suspend fun signUp(name: String, email: String, phone: String, password: String, currency: String): AuthResult {
        if (userDao.countByEmail(email.trim().lowercase()) > 0) return AuthResult.EmailAlreadyExists
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(password, salt)
        val user = User(
            name = name.trim(),
            email = email.trim().lowercase(),
            phone = phone.trim(),
            passwordHash = hash,
            salt = salt,
            currency = currency
        )
        val id = userDao.insert(user)
        return AuthResult.Success(user.copy(userId = id))
    }

    suspend fun login(email: String, password: String): AuthResult {
        val user = userDao.findByEmail(email.trim().lowercase()) ?: return AuthResult.UserNotFound
        val hash = SecurityUtils.hashPassword(password, user.salt)
        return if (hash == user.passwordHash) AuthResult.Success(user) else AuthResult.InvalidCredentials
    }

    suspend fun changePassword(user: User, newPassword: String) {
        val salt = SecurityUtils.generateSalt()
        val hash = SecurityUtils.hashPassword(newPassword, salt)
        userDao.update(user.copy(passwordHash = hash, salt = salt))
    }

    fun observeUser(userId: Long): Flow<User?> = userDao.observeUser(userId)

    suspend fun getUser(userId: Long): User? = userDao.getUser(userId)

    suspend fun updateUser(user: User) = userDao.update(user)

    suspend fun deleteAccount(userId: Long) = userDao.deleteUser(userId)
}
