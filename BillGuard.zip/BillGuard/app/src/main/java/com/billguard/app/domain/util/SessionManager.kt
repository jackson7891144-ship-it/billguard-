package com.billguard.app.domain.util

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.billguard.app.domain.AppThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "billguard_prefs")

/**
 * Everything that is "how the app should behave for this device" rather than "app data" lives
 * here: who is logged in, remember-me, theme, onboarding completion, and ULTRON/notification
 * toggles. Financial data always stays in Room.
 */
class SessionManager(private val context: Context) {

    private object Keys {
        val LOGGED_IN_USER_ID = longPreferencesKey("logged_in_user_id")
        val REMEMBER_ME = booleanPreferencesKey("remember_me")
        val ONBOARDING_DONE = booleanPreferencesKey("onboarding_done")
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val NOTIFICATIONS_ENABLED = booleanPreferencesKey("notifications_enabled")
        val ULTRON_ENABLED = booleanPreferencesKey("ultron_enabled")
        val ULTRON_PROACTIVE = booleanPreferencesKey("ultron_proactive")
        val APP_LOCK_ENABLED = booleanPreferencesKey("app_lock_enabled")
    }

    val loggedInUserId: Flow<Long?> = context.dataStore.data.map { it[Keys.LOGGED_IN_USER_ID] }
    val onboardingDone: Flow<Boolean> = context.dataStore.data.map { it[Keys.ONBOARDING_DONE] ?: false }
    val themeMode: Flow<AppThemeMode> = context.dataStore.data.map {
        runCatching { AppThemeMode.valueOf(it[Keys.THEME_MODE] ?: AppThemeMode.SYSTEM.name) }
            .getOrDefault(AppThemeMode.SYSTEM)
    }
    val notificationsEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.NOTIFICATIONS_ENABLED] ?: true }
    val ultronEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.ULTRON_ENABLED] ?: true }
    val ultronProactive: Flow<Boolean> = context.dataStore.data.map { it[Keys.ULTRON_PROACTIVE] ?: true }
    val appLockEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.APP_LOCK_ENABLED] ?: false }

    suspend fun setLoggedInUser(userId: Long?, rememberMe: Boolean = true) {
        context.dataStore.edit {
            if (userId == null) it.remove(Keys.LOGGED_IN_USER_ID) else it[Keys.LOGGED_IN_USER_ID] = userId
            it[Keys.REMEMBER_ME] = rememberMe
        }
    }

    suspend fun setOnboardingDone(done: Boolean) {
        context.dataStore.edit { it[Keys.ONBOARDING_DONE] = done }
    }

    suspend fun setThemeMode(mode: AppThemeMode) {
        context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.NOTIFICATIONS_ENABLED] = enabled }
    }

    suspend fun setUltronEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ULTRON_ENABLED] = enabled }
    }

    suspend fun setUltronProactive(enabled: Boolean) {
        context.dataStore.edit { it[Keys.ULTRON_PROACTIVE] = enabled }
    }

    suspend fun setAppLockEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.APP_LOCK_ENABLED] = enabled }
    }

    suspend fun logout() {
        context.dataStore.edit { it.remove(Keys.LOGGED_IN_USER_ID) }
    }
}
