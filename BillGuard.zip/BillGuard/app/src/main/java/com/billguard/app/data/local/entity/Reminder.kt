package com.billguard.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "reminders", indices = [Index("userId"), Index("reminderDateTime")])
data class Reminder(
    @PrimaryKey(autoGenerate = true) val reminderId: Long = 0,
    val userId: Long,
    val subscriptionId: Long? = null,
    val billId: Long? = null,
    val itemName: String,
    // Epoch millis of the exact moment this reminder should fire.
    val reminderDateTime: Long,
    val reminderType: String, // ReminderOffset.name, or "CUSTOM"
    val enabled: Boolean = true,
    // AlarmManager request code so it can be cancelled/rescheduled precisely.
    val alarmRequestCode: Int = 0
)
