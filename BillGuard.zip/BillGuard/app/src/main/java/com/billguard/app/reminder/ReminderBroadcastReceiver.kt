package com.billguard.app.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class ReminderBroadcastReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_REMINDER_ID = "extra_reminder_id"
        const val EXTRA_ITEM_NAME = "extra_item_name"
        const val EXTRA_IS_SUBSCRIPTION = "extra_is_subscription"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getLongExtra(EXTRA_REMINDER_ID, -1L)
        val itemName = intent.getStringExtra(EXTRA_ITEM_NAME) ?: "your item"
        val isSubscription = intent.getBooleanExtra(EXTRA_IS_SUBSCRIPTION, true)

        NotificationHelper.ensureChannels(context)
        NotificationHelper.showNotification(
            context = context,
            notificationId = reminderId.toInt(),
            title = "BillGuard reminder",
            message = if (isSubscription)
                "$itemName — check your renewal in the app to review or cancel before you're charged."
            else
                "$itemName — this bill is coming up. Open BillGuard for the full details.",
            channelId = NotificationHelper.CHANNEL_REMINDERS
        )
    }
}
