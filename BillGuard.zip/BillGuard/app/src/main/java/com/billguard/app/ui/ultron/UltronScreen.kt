package com.billguard.app.ui.ultron

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.ultron.UltronEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class ChatMessage(val text: String, val fromUser: Boolean)

val suggestedPrompts = listOf(
    "What is my next payment?",
    "How much do I spend every month?",
    "Which subscription is the most expensive?",
    "Which free trials are ending soon?",
    "Which subscriptions have autopay?",
    "How can I reduce recurring expenses?"
)

class UltronViewModel(private val container: AppContainer, private val userId: Long) : ViewModel() {
    private val _messages = MutableStateFlow(
        listOf(ChatMessage("Hi, I'm ULTRON. Ask me about your subscriptions, bills, or spending — I only use what's actually in your BillGuard data.", fromUser = false))
    )
    val messages: StateFlow<List<ChatMessage>> = _messages

    fun ask(query: String) {
        if (query.isBlank()) return
        _messages.value = _messages.value + ChatMessage(query, fromUser = true)
        viewModelScope.launch {
            val user = container.userRepository.getUser(userId)
            val subs = container.subscriptionRepository.getActiveOnce(userId)
            val bills = container.billRepository.getActiveOnce(userId)
            val response = UltronEngine.respond(query, user, subs, bills)
            _messages.value = _messages.value + ChatMessage(response, fromUser = false)
        }
    }
}

@Composable
fun UltronScreen(viewModel: UltronViewModel, initialQuery: String? = null) {
    val messages by viewModel.messages.collectAsState()
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(initialQuery) {
        if (!initialQuery.isNullOrBlank()) viewModel.ask(initialQuery)
    }
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) listState.animateScrollToItem(messages.size - 1)
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(32.dp).background(MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                Text("U", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Column {
                Text("ULTRON", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Your subscription & bill assistant", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        LazyColumn(
            state = listState,
            modifier = Modifier.weight(1f).fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(messages) { msg -> ChatBubble(msg) }
            if (messages.size <= 1) {
                item {
                    Column(Modifier.padding(top = 8.dp)) {
                        Text("Try asking:", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(6.dp))
                        suggestedPrompts.forEach { prompt ->
                            AssistChip(onClick = { viewModel.ask(prompt) }, label = { Text(prompt) }, modifier = Modifier.padding(bottom = 6.dp))
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(8.dp)) }
        }

        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input, onValueChange = { input = it },
                placeholder = { Text("Ask ULTRON...") },
                modifier = Modifier.weight(1f), singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = { viewModel.ask(input); input = "" }) {
                Icon(Icons.Filled.Send, contentDescription = "Send", tint = MaterialTheme.colorScheme.primary)
            }
        }
    }
}

@Composable
private fun ChatBubble(message: ChatMessage) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start) {
        Box(
            modifier = Modifier
                .fillMaxWidth(0.82f)
                .background(
                    if (message.fromUser) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant,
                    RoundedCornerShape(14.dp)
                )
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(
                message.text,
                color = if (message.fromUser) Color.White else MaterialTheme.colorScheme.onSurface,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}
