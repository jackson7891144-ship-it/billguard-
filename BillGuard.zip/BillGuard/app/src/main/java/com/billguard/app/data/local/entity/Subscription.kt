package com.billguard.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "subscriptions",
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["userId"],
        childColumns = ["userId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("userId"), Index("renewalDate")]
)
data class Subscription(
    @PrimaryKey(autoGenerate = true) val subscriptionId: Long = 0,
    val userId: Long,
    val name: String,
    val provider: String,
    val category: String, // SubscriptionCategory.name
    val amount: Double,
    val currencySymbol: String,
    val frequency: String, // Frequency.name
    val startDate: Long,
    val renewalDate: Long,
    val isTrial: Boolean = false,
    val trialStart: Long? = null,
    val trialEnd: Long? = null,
    val postTrialAmount: Double? = null,
    val paymentMethodId: Long? = null,
    val autopay: Boolean = true,
    val status: String = "ACTIVE", // ItemStatus.name
    val reminderOffsets: String = "SEVEN_DAYS,THREE_DAYS,ONE_DAY,SAME_DAY", // comma separated ReminderOffset names
    val iconKey: String = "default",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
