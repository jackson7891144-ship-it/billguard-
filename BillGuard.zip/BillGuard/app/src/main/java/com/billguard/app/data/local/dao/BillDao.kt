package com.billguard.app.data.local.dao

import androidx.room.*
import com.billguard.app.data.local.entity.Bill
import kotlinx.coroutines.flow.Flow

@Dao
interface BillDao {
    @Insert
    suspend fun insert(bill: Bill): Long

    @Update
    suspend fun update(bill: Bill)

    @Delete
    suspend fun delete(bill: Bill)

    @Query("SELECT * FROM bills WHERE userId = :userId ORDER BY dueDate ASC")
    fun observeAll(userId: Long): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE userId = :userId AND status = 'ACTIVE' ORDER BY dueDate ASC")
    fun observeActive(userId: Long): Flow<List<Bill>>

    @Query("SELECT * FROM bills WHERE billId = :id LIMIT 1")
    fun observeById(id: Long): Flow<Bill?>

    @Query("SELECT * FROM bills WHERE billId = :id LIMIT 1")
    suspend fun getById(id: Long): Bill?

    @Query("SELECT * FROM bills WHERE userId = :userId AND status = 'ACTIVE'")
    suspend fun getActiveOnce(userId: Long): List<Bill>

    @Query(
        """SELECT * FROM bills WHERE userId = :userId AND status = 'ACTIVE'
           AND (name LIKE '%' || :query || '%' OR provider LIKE '%' || :query || '%' OR category LIKE '%' || :query || '%')"""
    )
    fun search(userId: Long, query: String): Flow<List<Bill>>
}
