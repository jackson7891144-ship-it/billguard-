package com.billguard.app.ui.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronLeft
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.Bill
import com.billguard.app.data.local.entity.Subscription
import com.billguard.app.domain.util.DateCalculations
import com.billguard.app.ui.components.SectionCard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.time.YearMonth
import java.time.format.TextStyle
import java.util.Locale

data class CalendarItem(val name: String, val amount: Double, val currencySymbol: String, val date: LocalDate, val isSubscription: Boolean, val id: Long)

class CalendarViewModel(private val container: AppContainer, private val userId: Long) : ViewModel() {
    private val _items = MutableStateFlow<List<CalendarItem>>(emptyList())
    val items: StateFlow<List<CalendarItem>> = _items

    init {
        viewModelScope.launch {
            combine(
                container.subscriptionRepository.observeActive(userId),
                container.billRepository.observeActive(userId)
            ) { subs, bills -> buildItems(subs, bills) }.collectLatest { _items.value = it }
        }
    }

    private fun buildItems(subs: List<Subscription>, bills: List<Bill>): List<CalendarItem> {
        val list = mutableListOf<CalendarItem>()
        subs.forEach { list.add(CalendarItem(it.name, it.amount, it.currencySymbol, DateCalculations.epochToLocalDate(it.renewalDate), true, it.subscriptionId)) }
        bills.forEach { list.add(CalendarItem(it.name, it.amount, it.currencySymbol, DateCalculations.epochToLocalDate(it.dueDate), false, it.billId)) }
        return list
    }
}

@Composable
fun CalendarScreen(viewModel: CalendarViewModel, onOpenSubscription: (Long) -> Unit, onOpenBill: (Long) -> Unit) {
    val items by viewModel.items.collectAsState()
    var visibleMonth by remember { mutableStateOf(YearMonth.now()) }
    var selectedDate by remember { mutableStateOf(LocalDate.now()) }

    val itemsByDate = remember(items) { items.groupBy { it.date } }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { visibleMonth = visibleMonth.minusMonths(1) }) { Icon(Icons.Filled.ChevronLeft, contentDescription = "Previous month") }
            Text(
                "${visibleMonth.month.getDisplayName(TextStyle.FULL, Locale.getDefault())} ${visibleMonth.year}",
                style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold
            )
            IconButton(onClick = { visibleMonth = visibleMonth.plusMonths(1) }) { Icon(Icons.Filled.ChevronRight, contentDescription = "Next month") }
        }

        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            listOf("S", "M", "T", "W", "T", "F", "S").forEach {
                Text(it, modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.Center, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Spacer(Modifier.height(4.dp))

        val firstOfMonth = visibleMonth.atDay(1)
        val leadingBlanks = firstOfMonth.dayOfWeek.value % 7 // Sunday=0
        val daysInMonth = visibleMonth.lengthOfMonth()
        val cells = (0 until leadingBlanks).map { null } + (1..daysInMonth).map { visibleMonth.atDay(it) }

        LazyVerticalGrid(columns = GridCells.Fixed(7), modifier = Modifier.height(260.dp)) {
            items(cells) { date ->
                if (date == null) {
                    Box(Modifier.aspectRatio(1f))
                } else {
                    val hasItems = itemsByDate.containsKey(date)
                    val isSelected = date == selectedDate
                    val isToday = date == LocalDate.now()
                    Box(
                        modifier = Modifier
                            .aspectRatio(1f)
                            .padding(2.dp)
                            .clickable { selectedDate = date },
                        contentAlignment = Alignment.Center
                    ) {
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .background(
                                    when { isSelected -> MaterialTheme.colorScheme.primary; isToday -> MaterialTheme.colorScheme.surfaceVariant; else -> androidx.compose.ui.graphics.Color.Transparent },
                                    CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                date.dayOfMonth.toString(),
                                color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onBackground,
                                style = MaterialTheme.typography.bodyMedium
                            )
                        }
                        if (hasItems) {
                            Box(
                                Modifier
                                    .padding(top = 30.dp)
                                    .size(5.dp)
                                    .background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary, CircleShape)
                            )
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text(DateCalculations.formatDate(DateCalculations.localDateToEpoch(selectedDate)), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))

        val dayItems = itemsByDate[selectedDate].orEmpty()
        if (dayItems.isEmpty()) {
            Text("Nothing due on this date.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            dayItems.forEach { item ->
                SectionCard(onClick = { if (item.isSubscription) onOpenSubscription(item.id) else onOpenBill(item.id) }, modifier = Modifier.padding(bottom = 8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(item.name, style = MaterialTheme.typography.bodyLarge)
                        Text("${item.currencySymbol}${"%.2f".format(item.amount)}", style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
    }
}
