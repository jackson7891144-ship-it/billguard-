# BillGuard

**Never miss a bill. Never forget a subscription.**

A native Android app (Kotlin + Jetpack Compose) that keeps every OTT/streaming subscription
and recurring bill in one place, warns you before autopay renews, and includes an on-device
assistant called **ULTRON**.

---

## ⚠️ About the APK

This project was generated in a sandboxed environment with **no internet access and no Android
SDK installed**, so it was not possible to compile an actual `.apk` file there. What you have
instead is the **complete, real Android Studio source project** — every screen, the database,
the reminder/alarm system, and ULTRON are fully implemented, working code (not mockups).

To get an installable APK, pick either option:

### Option A — Android Studio (recommended, ~5 minutes)
1. Install [Android Studio](https://developer.android.com/studio) (free).
2. `File → Open` → select the `BillGuard` folder.
3. Let Gradle sync (downloads dependencies automatically — needs internet once).
4. `Build → Build App Bundle(s) / APK(s) → Build APK(s)`.
5. The APK lands in `app/build/outputs/apk/debug/app-debug.apk`. Copy it to your phone and
   install it (enable "Install unknown apps" for the app you use to open the file).
6. To run it straight from Android Studio on a connected phone or emulator, just press ▶ Run.

### Option B — Let GitHub build it for you (no Android Studio needed)
This project includes `.github/workflows/build-apk.yml`, a ready-to-go GitHub Actions workflow.
1. Create a free GitHub repository and push this project to it (or upload the files via
   GitHub's web UI).
2. Go to the repo's **Actions** tab — the workflow runs automatically on push (or click
   **Run workflow** to trigger it manually).
3. When it finishes (a few minutes), open the completed run and download the
   **BillGuard-debug-apk** artifact — that's your real, installable APK, compiled on GitHub's
   own servers.

Either path produces a genuinely working APK; nothing about it is simulated.

---

## What's implemented

- **Auth**: local, secure sign up / login (salted + hashed passwords, never plaintext).
  Architecture is ready to swap in Firebase Authentication / Google Sign-In later — see
  `User.authProvider` and `UserRepository`.
- **Dashboard**: monthly/yearly spend, spending-target progress bar, upcoming payments, active
  subscription / trial / autopay counts, and a live ULTRON summary card.
- **Subscriptions**: add/edit/delete/pause/cancel, categories, billing frequency, free-trial
  tracking, autopay toggle, per-item reminder offsets, payment history, detail screen.
- **Bills**: same core flow for recurring bills (electricity, rent, EMI, etc.).
- **Reminders & Alarms**: `AlarmManager` schedules exact-time alerts per your chosen offsets
  (14/7/3/2/1 days, same day); a daily `WorkManager` job proactively checks every subscription
  and bill and posts real Android notifications; alarms are re-armed automatically after a
  reboot.
- **ULTRON**: a chat screen plus a proactive dashboard card. It only ever answers from your
  actual stored data — next payment, monthly/yearly spend, most expensive item, autopay list,
  trials ending, overdue bills, and basic troubleshooting. It runs entirely on-device (no
  network call), so it keeps working offline and never invents numbers.
- **Calendar**: month view with a dot on any date that has a renewal/due date; tap a date to
  see what's due.
- **Analytics**: monthly/yearly totals, a category-breakdown donut chart, most expensive item.
- **Notification Center**: in-app log of every reminder/insight, mark read/unread, delete.
- **Settings**: profile, monthly spending target, notification toggle, light/dark/system theme,
  biometric app-lock toggle, ULTRON toggles, logout, delete account (cascades all data).
- **Theme**: light mode is white + green; dark mode is black + gray with green kept only as a
  small accent, exactly as requested.
- **Offline-first**: everything except the (non-existent) network call works with no internet —
  all data lives in a local Room database.
- **Security**: passwords are salted+hashed (SHA-256 × 10,000 iterations), never stored in
  plaintext; the payment-method model has no field for CVV, PINs, or banking passwords by
  design — BillGuard tracks and reminds, it never stores banking credentials.

## Known simplifications (first pass — easy to extend)

- **Payment Methods** management has a data model and DAO/repository, but no dedicated
  add/edit screen yet — subscriptions/bills can still be created without one.
- **Google Sign-In / Firebase Auth** are stubbed as a button; wiring in real Firebase requires
  your own `google-services.json` and Firebase project (kept out since this environment has no
  network to set that up or verify it).
- **Biometric app-lock** has a Settings toggle and the `androidx.biometric` dependency is
  included, but the actual `BiometricPrompt` gate on app-launch isn't wired in yet.
- **Data export** (JSON) is straightforward to add on top of the existing repositories but
  isn't included in this pass.
- Bills currently open straight into the edit screen rather than having a separate read-only
  detail page (subscriptions have the full detail page from the spec).

None of this code has been run through an actual Android build in this environment (no SDK, no
network) — I've checked it carefully by hand (package/import consistency, no duplicate
declarations, balanced braces, matching constructor signatures across every screen), but a
first real `./gradlew build` may still surface a small issue or two, most likely a stray import.
If that happens, the error message will point at the exact line — it's normal for a project
this size on its first real compile, and nothing about the underlying design changes.

## Architecture

- **MVVM**: one `ViewModel` per screen, `AppContainer` does simple manual dependency injection
  (no Hilt, to keep the build lean).
- **Room** for local storage (7 entities: User, Subscription, Bill, PaymentMethod,
  PaymentHistory, Reminder, Notification).
- **Kotlin Coroutines + Flow / StateFlow** throughout.
- **Jetpack Compose + Navigation-Compose** for the UI.
- **WorkManager** for the daily proactive renewal check; **AlarmManager** for exact per-item
  reminders; both survive a device reboot via `BootReceiver`.
- All date/recurrence math goes through `DateCalculations` (built on `java.time`), so month
  lengths, leap years, and local time zones are handled correctly instead of naïve millisecond
  arithmetic.
