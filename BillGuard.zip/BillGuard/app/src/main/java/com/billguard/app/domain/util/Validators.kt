package com.billguard.app.domain.util

import android.util.Patterns

object Validators {
    fun isValidEmail(email: String): Boolean =
        email.isNotBlank() && Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()

    fun isValidPhone(phone: String): Boolean =
        phone.trim().replace(" ", "").replace("-", "").let {
            it.length in 7..15 && it.all { c -> c.isDigit() || c == '+' }
        }

    /** At least 8 chars, one letter and one digit — a reasonable bar without being punishing. */
    fun isStrongPassword(password: String): Boolean =
        password.length >= 8 && password.any { it.isLetter() } && password.any { it.isDigit() }

    fun passwordsMatch(password: String, confirm: String): Boolean = password == confirm && password.isNotEmpty()

    fun isValidAmount(text: String): Boolean {
        val value = text.toDoubleOrNull() ?: return false
        return value > 0.0 && value < 100_000_000.0
    }

    fun isNotBlank(text: String): Boolean = text.trim().isNotEmpty()
}
