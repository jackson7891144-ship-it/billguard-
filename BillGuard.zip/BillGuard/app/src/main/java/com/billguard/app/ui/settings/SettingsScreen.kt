package com.billguard.app.ui.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.User
import com.billguard.app.domain.AppThemeMode
import com.billguard.app.domain.util.Validators
import com.billguard.app.ui.components.SectionCard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class SettingsState(
    val user: User? = null,
    val themeMode: AppThemeMode = AppThemeMode.SYSTEM,
    val notificationsEnabled: Boolean = true,
    val ultronEnabled: Boolean = true,
    val ultronProactive: Boolean = true,
    val appLockEnabled: Boolean = false
)

class SettingsViewModel(private val container: AppContainer, private val userId: Long) : ViewModel() {
    private val _state = MutableStateFlow(SettingsState())
    val state: StateFlow<SettingsState> = _state

    init {
        viewModelScope.launch {
            combine(
                container.userRepository.observeUser(userId),
                container.sessionManager.themeMode,
                container.sessionManager.notificationsEnabled,
                container.sessionManager.ultronEnabled,
                container.sessionManager.ultronProactive,
                container.sessionManager.appLockEnabled
            ) { values ->
                SettingsState(
                    user = values[0] as User?,
                    themeMode = values[1] as AppThemeMode,
                    notificationsEnabled = values[2] as Boolean,
                    ultronEnabled = values[3] as Boolean,
                    ultronProactive = values[4] as Boolean,
                    appLockEnabled = values[5] as Boolean
                )
            }.collectLatest { _state.value = it }
        }
    }

    fun setThemeMode(mode: AppThemeMode) { viewModelScope.launch { container.sessionManager.setThemeMode(mode) } }
    fun setNotificationsEnabled(v: Boolean) { viewModelScope.launch { container.sessionManager.setNotificationsEnabled(v) } }
    fun setUltronEnabled(v: Boolean) { viewModelScope.launch { container.sessionManager.setUltronEnabled(v) } }
    fun setUltronProactive(v: Boolean) { viewModelScope.launch { container.sessionManager.setUltronProactive(v) } }
    fun setAppLockEnabled(v: Boolean) { viewModelScope.launch { container.sessionManager.setAppLockEnabled(v) } }

    fun setMonthlyTarget(target: Double?) {
        val user = _state.value.user ?: return
        viewModelScope.launch { container.userRepository.updateUser(user.copy(monthlySpendingTarget = target)) }
    }

    fun logout(onDone: () -> Unit) { viewModelScope.launch { container.sessionManager.logout(); onDone() } }

    fun deleteAccount(onDone: () -> Unit) {
        viewModelScope.launch {
            container.sessionManager.logout()
            container.userRepository.deleteAccount(userId) // cascades subscriptions/bills via FK
            onDone()
        }
    }
}

@Composable
fun SettingsScreen(viewModel: SettingsViewModel, onLoggedOut: () -> Unit) {
    val state by viewModel.state.collectAsState()
    var targetInput by remember(state.user?.monthlySpendingTarget) { mutableStateOf(state.user?.monthlySpendingTarget?.toString() ?: "") }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))

        SettingsSection("Account") {
            SettingsRow("Name", state.user?.name ?: "")
            SettingsRow("Email", state.user?.email ?: "")
            SettingsRow("Phone", state.user?.phone ?: "")
        }

        Spacer(Modifier.height(16.dp))
        SettingsSection("Spending Target") {
            Text("Get an ULTRON warning if your monthly recurring spend goes over this.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(
                    value = targetInput, onValueChange = { targetInput = it },
                    label = { Text("Monthly target (${state.user?.currencySymbol ?: ""})") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    modifier = Modifier.weight(1f), singleLine = true
                )
                Spacer(Modifier.width(8.dp))
                TextButton(onClick = { viewModel.setMonthlyTarget(if (Validators.isValidAmount(targetInput)) targetInput.toDouble() else null) }) { Text("Save") }
            }
        }

        Spacer(Modifier.height(16.dp))
        SettingsSection("Notifications") {
            ToggleRow("Notifications", state.notificationsEnabled, viewModel::setNotificationsEnabled)
        }

        Spacer(Modifier.height(16.dp))
        SettingsSection("Appearance") {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AppThemeMode.values().forEach { mode ->
                    FilterChip(
                        selected = state.themeMode == mode,
                        onClick = { viewModel.setThemeMode(mode) },
                        label = { Text(mode.name.lowercase().replaceFirstChar { it.uppercase() }) }
                    )
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        SettingsSection("Security") {
            ToggleRow("App Lock (biometric)", state.appLockEnabled, viewModel::setAppLockEnabled)
        }

        Spacer(Modifier.height(16.dp))
        SettingsSection("ULTRON") {
            ToggleRow("Enable ULTRON", state.ultronEnabled, viewModel::setUltronEnabled)
            ToggleRow("Proactive insights", state.ultronProactive, viewModel::setUltronProactive)
        }

        Spacer(Modifier.height(16.dp))
        SettingsSection("About") {
            SettingsRow("App Version", "1.0.0")
            SettingsRow("Powered by", "ULTRON (offline, on-device)")
        }

        Spacer(Modifier.height(20.dp))
        OutlinedButton(onClick = { viewModel.logout(onLoggedOut) }, modifier = Modifier.fillMaxWidth()) { Text("Logout") }
        Spacer(Modifier.height(10.dp))
        TextButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Delete Account & Data", color = MaterialTheme.colorScheme.error)
        }
        Spacer(Modifier.height(30.dp))
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete your account?") },
            text = { Text("This permanently deletes your account and every subscription, bill, and reminder stored in BillGuard. This can't be undone.") },
            confirmButton = { TextButton(onClick = { viewModel.deleteAccount(onLoggedOut) }) { Text("Delete Everything", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun SettingsSection(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(8.dp))
    SectionCard(content = content)
}

@Composable
private fun SettingsRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun ToggleRow(label: String, checked: Boolean, onToggle: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label)
        Switch(checked = checked, onCheckedChange = onToggle)
    }
}
