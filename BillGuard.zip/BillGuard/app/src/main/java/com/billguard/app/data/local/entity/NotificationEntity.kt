package com.billguard.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "notifications", indices = [Index("userId"), Index("createdAt")])
data class NotificationEntity(
    @PrimaryKey(autoGenerate = true) val notificationId: Long = 0,
    val userId: Long,
    val title: String,
    val message: String,
    val type: String, // NotificationType.name
    val relatedSubscriptionId: Long? = null,
    val relatedBillId: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val readStatus: Boolean = false
)
