package com.billguard.app.data.local.dao

import androidx.room.*
import com.billguard.app.data.local.entity.PaymentHistory
import kotlinx.coroutines.flow.Flow

@Dao
interface PaymentHistoryDao {
    @Insert
    suspend fun insert(entry: PaymentHistory): Long

    @Update
    suspend fun update(entry: PaymentHistory)

    @Delete
    suspend fun delete(entry: PaymentHistory)

    @Query("SELECT * FROM payment_history WHERE userId = :userId ORDER BY date DESC")
    fun observeAll(userId: Long): Flow<List<PaymentHistory>>

    @Query("SELECT * FROM payment_history WHERE userId = :userId AND subscriptionId = :subscriptionId ORDER BY date DESC")
    fun observeForSubscription(userId: Long, subscriptionId: Long): Flow<List<PaymentHistory>>

    @Query("SELECT * FROM payment_history WHERE userId = :userId AND billId = :billId ORDER BY date DESC")
    fun observeForBill(userId: Long, billId: Long): Flow<List<PaymentHistory>>
}
