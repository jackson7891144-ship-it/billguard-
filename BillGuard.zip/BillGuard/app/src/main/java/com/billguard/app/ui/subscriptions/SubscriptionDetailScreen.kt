package com.billguard.app.ui.subscriptions

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.PaymentHistory
import com.billguard.app.data.local.entity.Subscription
import com.billguard.app.domain.util.DateCalculations
import com.billguard.app.ui.components.ChipTone
import com.billguard.app.ui.components.SectionCard
import com.billguard.app.ui.components.StatusChip
import com.billguard.app.ultron.UltronEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch

data class SubscriptionDetailState(
    val subscription: Subscription? = null,
    val history: List<PaymentHistory> = emptyList(),
    val ultronNote: String = ""
)

class SubscriptionDetailViewModel(private val container: AppContainer, private val userId: Long, private val subscriptionId: Long) : ViewModel() {
    private val _state = MutableStateFlow(SubscriptionDetailState())
    val state: StateFlow<SubscriptionDetailState> = _state

    init {
        viewModelScope.launch {
            combine(
                container.subscriptionRepository.observeById(subscriptionId),
                container.paymentHistoryRepository.observeForSubscription(userId, subscriptionId)
            ) { sub, history -> sub to history }.collectLatest { (sub, history) ->
                val note = sub?.let {
                    val days = DateCalculations.daysRemaining(it.renewalDate)
                    when {
                        it.isTrial && it.trialEnd != null -> {
                            val trialDays = DateCalculations.daysRemaining(it.trialEnd)
                            "Free trial ends in $trialDays day${if (trialDays == 1L) "" else "s"}." + (it.postTrialAmount?.let { amt -> " ${it.currencySymbol}${"%.2f".format(amt)} may be charged after that." } ?: "")
                        }
                        it.autopay -> "Autopay is ON. ${it.name} is expected to renew in $days day${if (days == 1L) "" else "s"} for ${it.currencySymbol}${"%.2f".format(it.amount)}."
                        else -> "Autopay is OFF. You'll need to pay manually before ${DateCalculations.formatDate(it.renewalDate)} to keep this active."
                    }
                } ?: ""
                _state.value = SubscriptionDetailState(sub, history, note)
            }
        }
    }

    fun setStatus(status: String) {
        val sub = _state.value.subscription ?: return
        viewModelScope.launch { container.subscriptionRepository.setStatus(sub, status) }
    }

    fun delete(onDeleted: () -> Unit) {
        val sub = _state.value.subscription ?: return
        viewModelScope.launch {
            container.reminderRepository.deleteForSubscription(sub.subscriptionId)
            container.subscriptionRepository.delete(sub)
            onDeleted()
        }
    }

    fun markAsPaid() {
        val sub = _state.value.subscription ?: return
        viewModelScope.launch {
            container.paymentHistoryRepository.add(
                PaymentHistory(
                    userId = userId, subscriptionId = sub.subscriptionId, itemName = sub.name,
                    amount = sub.amount, currencySymbol = sub.currencySymbol,
                    date = System.currentTimeMillis(), status = "PAID"
                )
            )
            val nextDate = DateCalculations.advance(
                DateCalculations.epochToLocalDate(sub.renewalDate),
                runCatching { com.billguard.app.domain.Frequency.valueOf(sub.frequency) }.getOrDefault(com.billguard.app.domain.Frequency.MONTHLY)
            )
            container.subscriptionRepository.update(sub.copy(renewalDate = DateCalculations.localDateToEpoch(nextDate), status = "ACTIVE"))
        }
    }
}

@Composable
fun SubscriptionDetailScreen(
    viewModel: SubscriptionDetailViewModel,
    onEdit: (Long) -> Unit,
    onDeleted: () -> Unit,
    onAskUltron: (String) -> Unit
) {
    val state by viewModel.state.collectAsState()
    val sub = state.subscription ?: return
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Top) {
                Column {
                    Text(sub.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                    Text(sub.provider.ifBlank { sub.category }, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                StatusChip(
                    label = when (sub.status) { "TRIAL" -> "Free Trial"; "PAUSED" -> "Paused"; "CANCELLED" -> "Cancelled"; else -> "Active" },
                    tone = when (sub.status) { "CANCELLED" -> ChipTone.ERROR; "PAUSED" -> ChipTone.WARNING; else -> ChipTone.SUCCESS }
                )
            }
        }

        item { com.billguard.app.ui.components.UltronCard(state.ultronNote, isWarning = sub.autopay) }

        item {
            SectionCard {
                DetailRow("Amount", "${sub.currencySymbol}${"%.2f".format(sub.amount)}")
                DetailRow("Frequency", sub.frequency.lowercase().replaceFirstChar { it.uppercase() })
                DetailRow("Next Renewal", DateCalculations.formatDate(sub.renewalDate))
                DetailRow("Annual Estimate", "${sub.currencySymbol}${"%.2f".format(sub.amount * DateCalculations.cyclesPerYear(runCatching { com.billguard.app.domain.Frequency.valueOf(sub.frequency) }.getOrDefault(com.billguard.app.domain.Frequency.MONTHLY)))}")
                DetailRow("Autopay", if (sub.autopay) "ON" else "OFF")
                if (sub.notes.isNotBlank()) DetailRow("Notes", sub.notes)
            }
        }

        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { onEdit(sub.subscriptionId) }, modifier = Modifier.weight(1f)) { Text("Edit") }
                OutlinedButton(onClick = { viewModel.markAsPaid() }, modifier = Modifier.weight(1f)) { Text("Mark as Paid") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = { viewModel.setStatus(if (sub.status == "PAUSED") "ACTIVE" else "PAUSED") },
                    modifier = Modifier.weight(1f)
                ) { Text(if (sub.status == "PAUSED") "Resume" else "Pause") }
                OutlinedButton(onClick = { viewModel.setStatus("CANCELLED") }, modifier = Modifier.weight(1f)) { Text("Cancel") }
            }
        }
        item {
            OutlinedButton(
                onClick = { onAskUltron("Tell me about ${sub.name}") },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Ask ULTRON about this") }
        }
        item {
            TextButton(onClick = { showDeleteConfirm = true }, modifier = Modifier.fillMaxWidth()) {
                Text("Delete Subscription", color = MaterialTheme.colorScheme.error)
            }
        }

        if (state.history.isNotEmpty()) {
            item { Text("Payment History", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
            items(state.history) { entry ->
                SectionCard {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(DateCalculations.formatDate(entry.date), style = MaterialTheme.typography.bodyMedium)
                        Text("${entry.currencySymbol}${"%.2f".format(entry.amount)} · ${entry.status}", style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }
        item { Spacer(Modifier.height(40.dp)) }
    }

    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("Delete this subscription?") },
            text = { Text("This removes ${sub.name} and its reminders. This can't be undone.") },
            confirmButton = { TextButton(onClick = { viewModel.delete(onDeleted) }) { Text("Delete", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton(onClick = { showDeleteConfirm = false }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
    }
}
