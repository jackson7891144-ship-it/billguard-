package com.billguard.app.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "payment_history", indices = [Index("userId"), Index("date")])
data class PaymentHistory(
    @PrimaryKey(autoGenerate = true) val paymentId: Long = 0,
    val userId: Long,
    val subscriptionId: Long? = null,
    val billId: Long? = null,
    val itemName: String,
    val amount: Double,
    val currencySymbol: String,
    val date: Long,
    val status: String, // PaymentStatus.name
    val paymentMethodId: Long? = null
)
