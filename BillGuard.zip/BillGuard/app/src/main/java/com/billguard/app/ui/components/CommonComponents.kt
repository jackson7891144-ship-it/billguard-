package com.billguard.app.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.billguard.app.ui.theme.StatusError
import com.billguard.app.ui.theme.StatusWarning

@Composable
fun SectionCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .let { if (onClick != null) it.clickable { onClick() } else it },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp), content = content)
    }
}

@Composable
fun EmptyState(
    title: String,
    subtitle: String,
    actionLabel: String,
    onAction: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onAction, shape = RoundedCornerShape(12.dp)) { Text(actionLabel) }
    }
}

@Composable
fun StatusChip(label: String, tone: ChipTone = ChipTone.NEUTRAL) {
    val (bg, fg) = when (tone) {
        ChipTone.SUCCESS -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
        ChipTone.WARNING -> StatusWarning.copy(alpha = 0.18f) to StatusWarning
        ChipTone.ERROR -> StatusError.copy(alpha = 0.15f) to StatusError
        ChipTone.NEUTRAL -> MaterialTheme.colorScheme.surfaceVariant to MaterialTheme.colorScheme.onSurfaceVariant
    }
    Box(
        modifier = Modifier
            .background(bg, RoundedCornerShape(8.dp))
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(label, style = MaterialTheme.typography.labelMedium, color = fg)
    }
}

enum class ChipTone { NEUTRAL, SUCCESS, WARNING, ERROR }

@Composable
fun SpendingProgressBar(current: Double, target: Double, symbol: String) {
    val fraction = if (target > 0) (current / target).coerceIn(0.0, 1.5).toFloat() else 0f
    val overBudget = target > 0 && current > target
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Monthly Recurring Spending", style = MaterialTheme.typography.labelLarge)
            Text(
                "$symbol${"%.0f".format(current)}",
                style = MaterialTheme.typography.labelLarge,
                fontWeight = FontWeight.Bold,
                color = if (overBudget) StatusError else MaterialTheme.colorScheme.primary
            )
        }
        Spacer(Modifier.height(8.dp))
        LinearProgressIndicator(
            progress = { fraction.coerceAtMost(1f) },
            modifier = Modifier.fillMaxWidth().height(10.dp).clip(RoundedCornerShape(6.dp)),
            color = if (overBudget) StatusError else MaterialTheme.colorScheme.primary,
            trackColor = MaterialTheme.colorScheme.surfaceVariant
        )
        if (target > 0) {
            Spacer(Modifier.height(6.dp))
            Text(
                if (overBudget) "Over target of $symbol${"%.0f".format(target)}" else "Target: $symbol${"%.0f".format(target)}  ·  Remaining: $symbol${"%.0f".format((target - current).coerceAtLeast(0.0))}",
                style = MaterialTheme.typography.bodySmall,
                color = if (overBudget) StatusError else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun UltronCard(message: String, isWarning: Boolean = false, modifier: Modifier = Modifier) {
    SectionCard(modifier = modifier) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(28.dp)
                    .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("U", color = Color.White, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.width(10.dp))
            Text("ULTRON", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            if (isWarning) {
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Filled.Warning, contentDescription = "Warning", tint = StatusWarning, modifier = Modifier.size(16.dp))
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium)
    }
}
