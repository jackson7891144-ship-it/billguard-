package com.billguard.app.data.repository

import com.billguard.app.data.local.dao.SubscriptionDao
import com.billguard.app.data.local.entity.Subscription
import kotlinx.coroutines.flow.Flow

class SubscriptionRepository(private val dao: SubscriptionDao) {
    fun observeAll(userId: Long): Flow<List<Subscription>> = dao.observeAll(userId)
    fun observeActive(userId: Long): Flow<List<Subscription>> = dao.observeActive(userId)
    fun observeById(id: Long): Flow<Subscription?> = dao.observeById(id)
    fun observeTrials(userId: Long): Flow<List<Subscription>> = dao.observeTrials(userId)
    fun observeAutopay(userId: Long): Flow<List<Subscription>> = dao.observeAutopay(userId)
    fun search(userId: Long, query: String): Flow<List<Subscription>> = dao.search(userId, query)

    suspend fun getActiveOnce(userId: Long): List<Subscription> = dao.getActiveOnce(userId)
    suspend fun getById(id: Long): Subscription? = dao.getById(id)

    suspend fun add(subscription: Subscription): Long = dao.insert(subscription)
    suspend fun update(subscription: Subscription) = dao.update(subscription)
    suspend fun delete(subscription: Subscription) = dao.delete(subscription)

    suspend fun setStatus(subscription: Subscription, status: String) = dao.update(subscription.copy(status = status))
    suspend fun setAutopay(subscription: Subscription, autopay: Boolean) = dao.update(subscription.copy(autopay = autopay))
}
