package com.billguard.app.data.local.entity

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "bills",
    foreignKeys = [ForeignKey(
        entity = User::class,
        parentColumns = ["userId"],
        childColumns = ["userId"],
        onDelete = ForeignKey.CASCADE
    )],
    indices = [Index("userId"), Index("dueDate")]
)
data class Bill(
    @PrimaryKey(autoGenerate = true) val billId: Long = 0,
    val userId: Long,
    val name: String,
    val provider: String,
    val category: String, // BillCategory.name
    val amount: Double,
    val currencySymbol: String,
    val frequency: String, // Frequency.name
    val dueDate: Long,
    val paymentMethodId: Long? = null,
    val autopay: Boolean = false,
    val status: String = "ACTIVE", // ItemStatus.name
    val reminderOffsets: String = "SEVEN_DAYS,THREE_DAYS,ONE_DAY,SAME_DAY",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
