package com.billguard.app

import android.app.Application
import com.billguard.app.reminder.NotificationHelper

/** Minimal, deliberate use of a static ref: only for reaching system services (AlarmManager)
 *  from ViewModels. Everything else flows through AppContainer via constructor injection. */
object BillGuardAppRef {
    lateinit var appContext: android.content.Context
}

class BillGuardApplication : Application() {
    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        BillGuardAppRef.appContext = this
        container = AppContainer(this)
        NotificationHelper.ensureChannels(this)
    }
}
