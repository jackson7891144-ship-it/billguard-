package com.billguard.app.ui.bills

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.billguard.app.AppContainer
import com.billguard.app.data.local.entity.Bill
import com.billguard.app.domain.util.DateCalculations
import com.billguard.app.ui.components.ChipTone
import com.billguard.app.ui.components.EmptyState
import com.billguard.app.ui.components.SectionCard
import com.billguard.app.ui.components.StatusChip
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class BillsViewModel(private val container: AppContainer, private val userId: Long) : ViewModel() {
    private val _bills = MutableStateFlow<List<Bill>>(emptyList())
    val bills: StateFlow<List<Bill>> = _bills

    init {
        viewModelScope.launch {
            container.billRepository.observeAll(userId).collectLatest { _bills.value = it }
        }
    }
}

@Composable
fun BillsListScreen(viewModel: BillsViewModel, onAdd: () -> Unit, onOpen: (Long) -> Unit) {
    val bills by viewModel.bills.collectAsState()
    val active = bills.filter { it.status != "CANCELLED" }

    if (active.isEmpty()) {
        EmptyState(
            title = "No recurring bills yet.",
            subtitle = "Add electricity, rent, internet, or any other recurring bill to track its due date.",
            actionLabel = "+ Add Bill",
            onAction = onAdd
        )
        return
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item { Text("Bills", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        items(active, key = { it.billId }) { bill ->
            SectionCard(onClick = { onOpen(bill.billId) }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text(bill.name, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Medium)
                        Text(bill.provider.ifBlank { bill.category }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Column(horizontalAlignment = androidx.compose.ui.Alignment.End) {
                        Text("${bill.currencySymbol}${"%.0f".format(bill.amount)}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        Spacer(Modifier.height(4.dp))
                        val days = DateCalculations.daysRemaining(bill.dueDate)
                        StatusChip(
                            label = if (days < 0) "Overdue" else if (days == 0L) "Due today" else "${days}d left",
                            tone = when { days < 0 -> ChipTone.ERROR; days <= 3 -> ChipTone.WARNING; else -> ChipTone.NEUTRAL }
                        )
                    }
                }
            }
        }
        item { Spacer(Modifier.height(70.dp)) }
    }
}
