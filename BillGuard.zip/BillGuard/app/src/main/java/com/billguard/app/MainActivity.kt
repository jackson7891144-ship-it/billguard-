package com.billguard.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import com.billguard.app.domain.AppThemeMode
import com.billguard.app.reminder.WorkScheduler
import com.billguard.app.ui.navigation.BillGuardNavHost
import com.billguard.app.ui.theme.BillGuardTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* handled gracefully either way */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestNotificationPermissionIfNeeded()
        WorkScheduler.ensureDailyRenewalCheck(applicationContext)

        val container = (application as BillGuardApplication).container

        setContent {
            var themeMode by remember { mutableStateOf(AppThemeMode.SYSTEM) }
            val scope = androidx.compose.runtime.rememberCoroutineScope()
            LaunchedEffect(Unit) {
                container.sessionManager.themeMode.collect { themeMode = it }
            }
            val darkTheme = when (themeMode) {
                AppThemeMode.LIGHT -> false
                AppThemeMode.DARK -> true
                AppThemeMode.SYSTEM -> androidx.compose.foundation.isSystemInDarkTheme()
            }
            BillGuardTheme(darkTheme = darkTheme) {
                BillGuardNavHost(
                    container = container,
                    onThemeModeChange = { newMode ->
                        scope.launch { container.sessionManager.setThemeMode(newMode) }
                    }
                )
            }
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
