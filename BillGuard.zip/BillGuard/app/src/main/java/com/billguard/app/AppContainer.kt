package com.billguard.app

import android.content.Context
import com.billguard.app.data.local.AppDatabase
import com.billguard.app.data.repository.*
import com.billguard.app.domain.util.SessionManager

class AppContainer(context: Context) {
    private val database = AppDatabase.getInstance(context)

    val userRepository = UserRepository(database.userDao())
    val subscriptionRepository = SubscriptionRepository(database.subscriptionDao())
    val billRepository = BillRepository(database.billDao())
    val paymentMethodRepository = PaymentMethodRepository(database.paymentMethodDao())
    val paymentHistoryRepository = PaymentHistoryRepository(database.paymentHistoryDao())
    val reminderRepository = ReminderRepository(database.reminderDao())
    val notificationRepository = NotificationRepository(database.notificationDao())
    val sessionManager = SessionManager(context)
}
