package com.billguard.app.domain

/** How often a subscription or bill recurs. */
enum class Frequency(val label: String, val monthsPerCycle: Double) {
    WEEKLY("Weekly", 0.23),
    MONTHLY("Monthly", 1.0),
    QUARTERLY("Quarterly", 3.0),
    HALF_YEARLY("Half-Yearly", 6.0),
    YEARLY("Yearly", 12.0),
    CUSTOM("Custom", 1.0)
}

enum class SubscriptionCategory(val label: String) {
    ENTERTAINMENT("Entertainment"),
    MUSIC("Music"),
    STREAMING("Streaming"),
    SOFTWARE("Software"),
    CLOUD_STORAGE("Cloud Storage"),
    EDUCATION("Education"),
    GAMING("Gaming"),
    FITNESS("Fitness"),
    SHOPPING("Shopping"),
    NEWS("News"),
    INTERNET("Internet"),
    OTHER("Other")
}

enum class BillCategory(val label: String) {
    ELECTRICITY("Electricity"),
    WATER("Water"),
    INTERNET("Internet"),
    MOBILE("Mobile"),
    RENT("Rent"),
    INSURANCE("Insurance"),
    LOAN_EMI("Loan EMI"),
    CREDIT_CARD("Credit Card Bill"),
    STREAMING("Streaming"),
    SOFTWARE("Software"),
    OTHER("Other")
}

enum class ItemStatus(val label: String) {
    ACTIVE("Active"),
    PAUSED("Paused"),
    CANCELLED("Cancelled"),
    TRIAL("Free Trial")
}

enum class PaymentStatus(val label: String) {
    UPCOMING("Upcoming"),
    PAID("Paid"),
    PENDING("Pending"),
    FAILED("Failed"),
    OVERDUE("Overdue"),
    CANCELLED("Cancelled")
}

enum class PaymentMethodType(val label: String) {
    UPI("UPI"),
    CREDIT_CARD("Credit Card"),
    DEBIT_CARD("Debit Card"),
    BANK_ACCOUNT("Bank Account"),
    WALLET("Wallet"),
    CASH("Cash"),
    OTHER("Other")
}

enum class ReminderOffset(val label: String, val daysBefore: Int) {
    FOURTEEN_DAYS("14 days before", 14),
    SEVEN_DAYS("7 days before", 7),
    THREE_DAYS("3 days before", 3),
    TWO_DAYS("2 days before", 2),
    ONE_DAY("1 day before", 1),
    SAME_DAY("Same day", 0)
}

enum class NotificationType(val label: String) {
    PAYMENT_REMINDER("Payment reminder"),
    TRIAL_REMINDER("Trial reminder"),
    AUTOPAY_WARNING("Autopay warning"),
    BILL_OVERDUE("Bill overdue"),
    FAILED_PAYMENT("Failed payment"),
    ULTRON_INSIGHT("ULTRON insight"),
    SPENDING_WARNING("Spending warning")
}

enum class AppThemeMode { LIGHT, DARK, SYSTEM }
