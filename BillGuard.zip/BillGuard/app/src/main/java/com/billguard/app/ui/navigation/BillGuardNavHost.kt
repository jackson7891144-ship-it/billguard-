package com.billguard.app.ui.navigation

import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.billguard.app.AppContainer
import com.billguard.app.domain.AppThemeMode
import com.billguard.app.reminder.WorkScheduler
import com.billguard.app.ui.analytics.AnalyticsScreen
import com.billguard.app.ui.analytics.AnalyticsViewModel
import com.billguard.app.ui.auth.AuthViewModel
import com.billguard.app.ui.auth.LoginScreen
import com.billguard.app.ui.auth.SignUpScreen
import com.billguard.app.ui.bills.AddEditBillScreen
import com.billguard.app.ui.bills.AddEditBillViewModel
import com.billguard.app.ui.main.MainScreen
import com.billguard.app.ui.notifications.NotificationCenterScreen
import com.billguard.app.ui.notifications.NotificationsViewModel
import com.billguard.app.ui.onboarding.OnboardingScreen
import com.billguard.app.ui.settings.SettingsScreen
import com.billguard.app.ui.settings.SettingsViewModel
import com.billguard.app.ui.splash.SplashScreen
import com.billguard.app.ui.subscriptions.AddEditSubscriptionScreen
import com.billguard.app.ui.subscriptions.AddEditSubscriptionViewModel
import com.billguard.app.ui.subscriptions.SubscriptionDetailScreen
import com.billguard.app.ui.subscriptions.SubscriptionDetailViewModel
import com.billguard.app.ui.ultron.UltronScreen
import com.billguard.app.ui.ultron.UltronViewModel
import com.billguard.app.ui.util.viewModel
import kotlinx.coroutines.launch

@Composable
fun BillGuardNavHost(container: AppContainer, onThemeModeChange: (AppThemeMode) -> Unit) {
    val navController = rememberNavController()
    val loggedInUserId by container.sessionManager.loggedInUserId.collectAsState(initial = null)
    val onboardingDone by container.sessionManager.onboardingDone.collectAsState(initial = false)

    NavHost(navController = navController, startDestination = Screen.Splash.route) {

        composable(Screen.Splash.route) {
            SplashScreen(onFinished = {
                val destination = when {
                    loggedInUserId == null -> Screen.Login.route
                    !onboardingDone -> Screen.Onboarding.route
                    else -> Screen.Main.route
                }
                navController.navigate(destination) { popUpTo(Screen.Splash.route) { inclusive = true } }
            })
        }

        composable(Screen.Login.route) {
            val vm: AuthViewModel = viewModel { AuthViewModel(container.userRepository, container.sessionManager) }
            LoginScreen(
                viewModel = vm,
                onLoginSuccess = {
                    navController.navigate(Screen.Main.route) { popUpTo(Screen.Login.route) { inclusive = true } }
                },
                onNavigateToSignUp = { navController.navigate(Screen.SignUp.route) }
            )
        }

        composable(Screen.SignUp.route) {
            val vm: AuthViewModel = viewModel { AuthViewModel(container.userRepository, container.sessionManager) }
            SignUpScreen(
                viewModel = vm,
                onSignUpSuccess = { navController.navigate(Screen.Onboarding.route) { popUpTo(Screen.SignUp.route) { inclusive = true } } },
                onNavigateToLogin = { navController.navigate(Screen.Login.route) }
            )
        }

        composable(Screen.Onboarding.route) {
            val scope = androidx.compose.runtime.rememberCoroutineScope()
            val userId = loggedInUserId
            OnboardingScreen(onFinished = { symbol, code ->
                scope.launch {
                    if (userId != null) {
                        container.userRepository.getUser(userId)?.let {
                            container.userRepository.updateUser(it.copy(currency = code, currencySymbol = symbol))
                        }
                    }
                    container.sessionManager.setOnboardingDone(true)
                    navController.navigate(Screen.Main.route) { popUpTo(Screen.Onboarding.route) { inclusive = true } }
                }
            })
        }

        composable(Screen.Main.route) {
            val userId = loggedInUserId
            if (userId != null) {
                LaunchedEffect(userId) { WorkScheduler.runOnce(com.billguard.app.BillGuardAppRef.appContext) }
                MainScreen(container = container, userId = userId, outerNav = navController, onThemeModeChange = onThemeModeChange)
            }
        }

        composable(Screen.AddSubscription.route) {
            val userId = loggedInUserId ?: return@composable
            val vm: AddEditSubscriptionViewModel = viewModel { AddEditSubscriptionViewModel(container, userId, null) }
            SimpleScreenScaffold("Add Subscription", navController) {
                AddEditSubscriptionScreen(viewModel = vm, onSaved = { navController.popBackStack() })
            }
        }

        composable(
            Screen.EditSubscription.route,
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { backStackEntry ->
            val userId = loggedInUserId ?: return@composable
            val id = backStackEntry.arguments?.getLong("id") ?: return@composable
            val vm: AddEditSubscriptionViewModel = viewModel { AddEditSubscriptionViewModel(container, userId, id) }
            SimpleScreenScaffold("Edit Subscription", navController) {
                AddEditSubscriptionScreen(viewModel = vm, onSaved = { navController.popBackStack() })
            }
        }

        composable(
            Screen.SubscriptionDetail.route,
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { backStackEntry ->
            val userId = loggedInUserId ?: return@composable
            val id = backStackEntry.arguments?.getLong("id") ?: return@composable
            val vm: SubscriptionDetailViewModel = viewModel { SubscriptionDetailViewModel(container, userId, id) }
            SimpleScreenScaffold("Subscription", navController) {
                SubscriptionDetailScreen(
                    viewModel = vm,
                    onEdit = { navController.navigate(Screen.EditSubscription.path(it)) },
                    onDeleted = { navController.popBackStack() },
                    onAskUltron = { query ->
                        navController.currentBackStackEntry?.savedStateHandle?.set("ultron_query", query)
                        navController.navigate(Screen.Ultron.route)
                    }
                )
            }
        }

        composable(Screen.AddBill.route) {
            val userId = loggedInUserId ?: return@composable
            val vm: AddEditBillViewModel = viewModel { AddEditBillViewModel(container, userId, null) }
            SimpleScreenScaffold("Add Bill", navController) {
                AddEditBillScreen(viewModel = vm, onSaved = { navController.popBackStack() })
            }
        }

        composable(
            Screen.EditBill.route,
            arguments = listOf(navArgument("id") { type = NavType.LongType })
        ) { backStackEntry ->
            val userId = loggedInUserId ?: return@composable
            val id = backStackEntry.arguments?.getLong("id") ?: return@composable
            val vm: AddEditBillViewModel = viewModel { AddEditBillViewModel(container, userId, id) }
            SimpleScreenScaffold("Bill", navController) {
                AddEditBillScreen(viewModel = vm, onSaved = { navController.popBackStack() })
            }
        }

        composable(Screen.Analytics.route) {
            val userId = loggedInUserId ?: return@composable
            val vm: AnalyticsViewModel = viewModel { AnalyticsViewModel(container, userId) }
            SimpleScreenScaffold("Analytics", navController) { AnalyticsScreen(viewModel = vm) }
        }

        composable(Screen.Notifications.route) {
            val userId = loggedInUserId ?: return@composable
            val vm: NotificationsViewModel = viewModel { NotificationsViewModel(container, userId) }
            SimpleScreenScaffold("Notifications", navController) {
                NotificationCenterScreen(
                    viewModel = vm,
                    onOpenSubscription = { navController.navigate(Screen.SubscriptionDetail.path(it)) },
                    onOpenBill = { navController.navigate(Screen.EditBill.path(it)) }
                )
            }
        }

        composable(Screen.Settings.route) {
            val userId = loggedInUserId ?: return@composable
            val vm: SettingsViewModel = viewModel { SettingsViewModel(container, userId) }
            SimpleScreenScaffold("Settings", navController) {
                SettingsScreen(viewModel = vm, onLoggedOut = {
                    navController.navigate(Screen.Login.route) { popUpTo(0) }
                })
            }
        }

        composable(Screen.Ultron.route) {
            val userId = loggedInUserId ?: return@composable
            val vm: UltronViewModel = viewModel { UltronViewModel(container, userId) }
            val query = navController.previousBackStackEntry?.savedStateHandle?.get<String>("ultron_query")
            SimpleScreenScaffold("ULTRON", navController) { UltronScreen(viewModel = vm, initialQuery = query) }
        }
    }
}

@Composable
private fun SimpleScreenScaffold(title: String, navController: androidx.navigation.NavHostController, content: @Composable () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(title) },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        androidx.compose.foundation.layout.Box(modifier = Modifier.padding(padding)) { content() }
    }
}
