# Keep Room entities and DAOs
-keep class com.billguard.app.data.local.entity.** { *; }
-keep interface com.billguard.app.data.local.dao.** { *; }

# Keep BroadcastReceivers (invoked by the OS, not from app code paths ProGuard can trace)
-keep class com.billguard.app.reminder.ReminderBroadcastReceiver { *; }
-keep class com.billguard.app.reminder.BootReceiver { *; }
