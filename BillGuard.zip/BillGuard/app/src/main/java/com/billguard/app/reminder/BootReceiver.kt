package com.billguard.app.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager

/**
 * AlarmManager alarms are wiped on reboot. This listens for BOOT_COMPLETED and re-schedules
 * every enabled reminder from Room via a short-lived worker (a BroadcastReceiver's onReceive
 * must return quickly, so the actual DB read/reschedule work happens off this thread).
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val request = OneTimeWorkRequestBuilder<RescheduleRemindersWorker>().build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "reschedule_reminders_after_boot", ExistingWorkPolicy.REPLACE, request
        )
    }
}
