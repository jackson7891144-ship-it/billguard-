package com.billguard.app.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.billguard.app.MainActivity
import com.billguard.app.R

object NotificationHelper {
    const val CHANNEL_REMINDERS = "billguard_reminders"
    const val CHANNEL_ULTRON = "billguard_ultron"

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = context.getSystemService(NotificationManager::class.java)

        val reminders = NotificationChannel(
            CHANNEL_REMINDERS, "Payment & bill reminders", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Upcoming subscription renewals and bill due dates"
            enableLights(true)
            lightColor = Color.parseColor("#1FAA59")
            enableVibration(true)
        }

        val ultron = NotificationChannel(
            CHANNEL_ULTRON, "ULTRON insights", NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Proactive spending insights and warnings from ULTRON"
        }

        manager.createNotificationChannel(reminders)
        manager.createNotificationChannel(ultron)
    }

    /**
     * Posts a real notification. Safe to call even if POST_NOTIFICATIONS was denied — it simply
     * no-ops instead of crashing (see section 33: never crash on a denied permission).
     */
    fun showNotification(
        context: Context,
        notificationId: Int,
        title: String,
        message: String,
        channelId: String = CHANNEL_REMINDERS
    ) {
        if (!NotificationManagerCompat.from(context).areNotificationsEnabled()) return

        val openIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = android.app.PendingIntent.getActivity(
            context, notificationId, openIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(message)
            .setStyle(NotificationCompat.BigTextStyle().bigText(message))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)

        runCatching {
            NotificationManagerCompat.from(context).notify(notificationId, builder.build())
        }
        // SecurityException here means POST_NOTIFICATIONS was denied at runtime; we swallow it
        // deliberately rather than crash, per the "handle denied permissions gracefully" requirement.
    }
}
