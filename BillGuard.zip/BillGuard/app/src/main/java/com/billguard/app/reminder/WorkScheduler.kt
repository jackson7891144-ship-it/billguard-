package com.billguard.app.reminder

import android.content.Context
import androidx.work.*
import java.util.concurrent.TimeUnit

object WorkScheduler {
    private const val UNIQUE_WORK_NAME = "billguard_daily_renewal_check"

    fun ensureDailyRenewalCheck(context: Context) {
        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(false)
            .build()

        val request = PeriodicWorkRequestBuilder<RenewalCheckWorker>(24, TimeUnit.HOURS)
            .setConstraints(constraints)
            .setBackoffCriteria(BackoffPolicy.LINEAR, 15, TimeUnit.MINUTES)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            UNIQUE_WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request
        )
    }

    /** Runs the check once immediately (e.g. right after login) instead of waiting up to 24h. */
    fun runOnce(context: Context) {
        val request = OneTimeWorkRequestBuilder<RenewalCheckWorker>().build()
        WorkManager.getInstance(context).enqueue(request)
    }
}
